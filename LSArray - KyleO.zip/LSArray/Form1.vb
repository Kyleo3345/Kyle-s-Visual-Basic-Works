﻿Public Class Form1
    Const intMAX_SUBSCRIPT As Integer = 9
    Dim intValues(intMAX_SUBSCRIPT) As Integer
    Private Sub btnInputint_Click(sender As Object, e As EventArgs) Handles btnInputint.Click
        lstNumbers.Items.Clear()
        lstNumbers.Items.Add("Input Numbers")
        Dim intCounter As Integer = 0

        Do While intCounter < intValues.Length
            Dim strInput As String = InputBox("Enter a Number.", "Number" & (intCounter + 1).ToString)
            Dim intVal As Integer
            Try
                intVal = CInt(strInput)
                intValues(intCounter) = intVal
                lblMessage.Text = String.Empty
                lstNumbers.Items.Add(intVal)
                intCounter += 1
            Catch ex As Exception
                lblMessage.Text = "Please enter valid number."
            End Try

        Loop

    End Sub

    Private Sub btnDisminandmax_Click(sender As Object, e As EventArgs) Handles btnDisminandmax.Click
        Dim result1 As Integer = Largest()
        Dim result2 As Integer = Smallest()

        lblMessage.Text = "The Largest number is: " & result1.ToString() & ". And the Smallest number is: " & result2.ToString() & ". "

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstNumbers.Items.Clear()
        lblMessage.Text = String.Empty
    End Sub

    Function Largest() As Integer
        Dim intCounter As Integer
        Dim intLargest As Integer
        intLargest = intValues(0)
        For intCounter = 1 To (intValues.Count - 1)
            If intValues(intCounter) > intLargest Then
                intLargest = intValues(intCounter)
            End If
        Next
        Return intLargest
    End Function

    Function Smallest() As Integer
        Dim intCounter As Integer
        Dim intSmallest As Integer
        intSmallest = intValues(0)
        For intCounter = 1 To (intValues.Count - 1)
            If intValues(intCounter) > intSmallest Then
                intSmallest = intValues(intCounter)
            End If
        Next
        Return intSmallest
    End Function

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
