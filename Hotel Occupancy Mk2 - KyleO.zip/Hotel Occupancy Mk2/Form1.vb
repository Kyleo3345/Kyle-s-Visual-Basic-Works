﻿Public Class Form1
    Const MAX_FLOOR As Integer = 8
    Const ROOMS_PER_FLOOR As Double = 30
    Const TOTAL_ROOMS As Double = 240

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim strOut As String
        Dim strInput As Integer
        Dim intTemp As Integer
        Dim dblFloorRate As Double
        Dim dblFloorRooms As Double
        Dim intTotalRooms As Integer
        Dim roomsOccupied(ROOMS_PER_FLOOR) As Integer

        Dim floors() As String = {"1", "2", "3", "4", "5", "6", "7", "8"}
        For index = 0 To 7
            cboHotelFloor.Items.Add(floors(index))
        Next
        cboHotelFloor.SelectedIndex = 0

        If Not Integer.TryParse(strInput, roomsOccupied(intTemp)) Then
            MessageBox.Show("Enter a valid integer.")
        ElseIf roomsOccupied(intTemp) > 30 Or roomsOccupied(intTemp) < 0 Then
            MessageBox.Show("Enter number of rooms between 0 and 30 only")
        Else
            intTotalRooms += roomsOccupied(intTemp)
            dblFloorRate = roomsOccupied(intTemp) / dblFloorRooms
            strOut = "Floor: " & intTemp.ToString() & " Rooms Occupied: " &
                roomsOccupied(intTemp).ToString() & " Occupancy Rate: " &
                dblFloorRate.ToString("p")
            lstOutput.Items.Add(strOut)
        End If

        lblOOR.Text = dblFloorRate.ToString("c")
        lblTRO.Text = intTotalRooms.ToString("n")
        cboHotelFloor.SelectedIndex = +1

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstOutput.Items.Clear()
        lblOOR.Text = String.Empty
        lblTRO.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

    End Sub
End Class
