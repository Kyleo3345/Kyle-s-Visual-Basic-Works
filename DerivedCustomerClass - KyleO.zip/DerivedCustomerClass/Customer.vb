﻿Public Class Customer
    Private CustomerNumber As Integer
    Private MailingList As Boolean
    Private Comments As String

    Public Property get_CustomerNum() As String
        Get
            Return CustomerNumber
        End Get
        Set(value As String)
            CustomerNumber = value
        End Set
    End Property

    Public Property get_MailingList() As String
        Get
            Return MailingList
        End Get
        Set(value As String)
            MailingList = value
        End Set
    End Property

    Public Property get_Comments As String
        Get
            Return Comments
        End Get
        Set(value As String)
            Comments = value
        End Set
    End Property
End Class
