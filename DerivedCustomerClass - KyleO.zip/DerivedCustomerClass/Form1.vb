﻿Public Class Form1

    Private Cust As New Collection
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        Dim CustomerInfo As New Customer

        CustomerInfo.get_CustomerNum = txtCustNum.Text
        CustomerInfo.get_MailingList = cboTF.Text
        CustomerInfo.get_Comments = txtComments.Text

        Cust.Add(CustomerInfo)

        lstOutput.Items.Add("Customer Num: " + CustomerInfo.get_CustomerNum + " " + "Mailing: " + CustomerInfo.get_MailingList)

    End Sub

    Private Sub btnRead_Click(sender As Object, e As EventArgs) Handles btnRead.Click

        Dim Selected As Customer = CType(Cust.Item(lstOutput.SelectedIndex + 1), Customer)

        MessageBox.Show("CustomerNum: " + Selected.get_CustomerNum + " Mailing: " + Selected.get_MailingList + " Comments: " + Selected.get_Comments)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
