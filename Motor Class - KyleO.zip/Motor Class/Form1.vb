﻿Public Class Form1

    Dim pes As String = "{0, 5}, {1, 12}, {2, 40}, {3, 12}, {4, 12}"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lstMotorStat.Items.Add(String.Format(pes, "MotorID", "Desc", "RPM", "Voltage", "Status"))


    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim ID As Integer
        Dim Desc As String
        Dim RPM As Integer
        Dim Volt As Integer
        Dim Stat As String

        ID = txtInputMotorID.Text
        Desc = txtInputDesc.Text
        RPM = txtInputRPM.Text
        Volt = txtInputVolts.Text
        Stat = cboStatus.Text

        lstMotorStat.Items.Add(String.Format(pes, ID, Desc, RPM, Volt, Stat))

    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        Dim ID As Integer
        Dim Desc As String
        Dim RPM As Integer
        Dim Volt As Integer
        Dim Stat As String

        ID = txtInputMotorID.Text
        Desc = txtInputDesc.Text
        RPM = txtInputRPM.Text
        Volt = txtInputVolts.Text
        Stat = cboStatus.Text

        Dim i As Integer = lstMotorStat.SelectedIndex
        lstMotorStat.Items.RemoveAt(i)

        lstMotorStat.Items.Insert(i, (String.Format(pes, ID, Desc, RPM, Volt, Stat)))

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        lstMotorStat.Items.Clear()
        lstMotorStat.Items.Add(String.Format(pes, "MotorID", "Desc", "RPM", "Voltage", "Status"))
        txtInputMotorID.Clear()
        txtInputDesc.Clear()
        txtInputRPM.Clear()
        txtInputVolts.Clear()
        cboStatus.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
