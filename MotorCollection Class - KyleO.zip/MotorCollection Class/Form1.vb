﻿Public Class Form1

    Private MotorInfomation As New Collection

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        Dim MotorINFO As New Motors

        MotorINFO.get_ID = txtInputMotorID.Text
        MotorINFO.get_Desc = txtInputDesc.Text
        MotorINFO.get_RPM = txtInputRPM.Text
        MotorINFO.get_Volts = txtInputVolts.Text
        MotorINFO.get_Status = cboStatus.Text

        MotorInfomation.Add(MotorINFO)

        lstMotorStat.Items.Add(MotorINFO.get_ID + " " + MotorINFO.get_Desc + " " + MotorINFO.get_RPM + " " +
                               MotorINFO.get_Volts + " " + MotorINFO.get_Status)

    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        Dim Edit As Motors = CType(MotorInfomation.Item(lstMotorStat.SelectedIndex + 1), Motors)

        Edit.get_ID = InputBox("Enter new ID", "ID", "Type here")
        Edit.get_Desc = InputBox("Enter new Desc", "Desc", "Type here")
        Edit.get_RPM = InputBox("Enter new RPM", "RPM", "Type here")
        Edit.get_Volts = InputBox("Enter new Voltage", "Volts", "Type here")
        Edit.get_Status = InputBox("Enter new Status", "Status", "Type here")

        lstMotorStat.Items.RemoveAt(lstMotorStat.SelectedIndex)

        MotorInfomation.Add(Edit)

        lstMotorStat.Items.Add(Edit.get_ID)

    End Sub

    Private Sub btnRead_Click(sender As Object, e As EventArgs) Handles btnRead.Click

        Dim Selected As Motors = CType(MotorInfomation.Item(lstMotorStat.SelectedIndex + 1), Motors)

        MessageBox.Show("Motor ID: " + Selected.get_ID + ";   Desc: " + Selected.get_Desc +
                        ";   RPM: " + Selected.get_RPM + ";   Voltage: " + Selected.get_Volts +
                        ";   Status: " + Selected.get_Status, "Motor Information", MessageBoxButtons.OK)

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        MotorInfomation.Remove(lstMotorStat.SelectedIndex + 1)
        lstMotorStat.Items.RemoveAt(lstMotorStat.SelectedIndex)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
