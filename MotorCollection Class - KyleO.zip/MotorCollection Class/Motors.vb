﻿Public Class Motors

    Private ID As String
    Private Desc As String
    Private RPM As String
    Private Volts As String
    Private Status As String

    Public Property get_ID() As String
        Get
            Return ID
        End Get
        Set(value As String)
            ID = value
        End Set
    End Property

    Public Property get_Desc() As String
        Get
            Return Desc
        End Get
        Set(value As String)
            Desc = value
        End Set
    End Property

    Public Property get_RPM() As String
        Get
            Return RPM
        End Get
        Set(value As String)
            RPM = value
        End Set
    End Property

    Public Property get_Volts() As String
        Get
            Return Volts
        End Get
        Set(value As String)
            Volts = value
        End Set
    End Property

    Public Property get_Status() As String
        Get
            Return Status
        End Get
        Set(value As String)
            Status = value
        End Set
    End Property

End Class
