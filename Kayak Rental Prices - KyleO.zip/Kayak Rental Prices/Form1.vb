﻿Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        KayakPriceDGV.DataSource = GetKayakRentalPrice()
    End Sub

    Private Function GetKayakRentalPrice() As DataTable

        Dim dtKayak As New DataTable
        Dim connS As String = ConfigurationManager.ConnectionStrings("KayakDB").ConnectionString

        Using conn As New SqlConnection(connS)
            Using cmd As New SqlCommand("SELECT * FROM RentalPrices", conn)

                conn.Open()

                Dim reader As SqlDataReader = cmd.ExecuteReader()

                dtKayak.Load(reader)

            End Using
        End Using

            Return dtKayak

    End Function

End Class
