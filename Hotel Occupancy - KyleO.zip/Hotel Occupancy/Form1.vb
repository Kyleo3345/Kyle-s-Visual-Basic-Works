﻿Public Class Form1

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Const ROOMS_PER_FLOOR As Integer = 30
        Const MAX_FLOOR As Integer = 8
        Dim occupancySum As Integer = 0
        Dim occupancy As Integer


        For Floor As Integer = 1 To MAX_FLOOR
            occupancy = CInt(txtNumberofRooms.Text)
            occupancySum += occupancy
            lstOutput.Items.Add("Floor: " & Floor & " Rooms Occupied: " & occupancy & " Occupancy Rate: " & (occupancy / ROOMS_PER_FLOOR) * 100 & "%")
        Next
        lstOutput.Items.Add("Total occupancy is " & occupancySum & " rooms - " & (occupancySum / (ROOMS_PER_FLOOR * MAX_FLOOR)) * 100 & "% full.")
        lblOOR.Text = occupancy.ToString("c")
            lblTRO.Text = occupancySum.ToString("n")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstOutput.Items.Clear()
        lblOOR.Text = String.Empty
        lblTRO.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
