﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim Days As Double = txtDays.Text
        Dim Miles As Double = txtMiles.Text
        Dim Gas As Decimal = 0.56
        Dim Lodging As Integer = 75
        Dim Food As Integer = 50
        Dim Total As Decimal



        Dim getFood = Days * Food
        Dim getLodging = Days * Lodging
        Dim getGas = Miles * Gas

        Total = getFood + getGas + getLodging

        lblOutput.Text = Total.ToString("c")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtDays.Text = ""
        txtMiles.Text = ""
        lblOutput.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
