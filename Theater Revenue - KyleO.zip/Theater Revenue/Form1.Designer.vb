﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtATS = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtAPPT = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtCTS = New System.Windows.Forms.TextBox()
        Me.txtCPPT = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblTGR = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblGCTS = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblGATS = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.lblTNR = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblNATS = New System.Windows.Forms.Label()
        Me.lblNCTS = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtATS)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtAPPT)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(273, 133)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Adult Ticket Sales"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Tickets sold :"
        '
        'txtATS
        '
        Me.txtATS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtATS.Location = New System.Drawing.Point(155, 76)
        Me.txtATS.Name = "txtATS"
        Me.txtATS.Size = New System.Drawing.Size(100, 26)
        Me.txtATS.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 20)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Price Per Ticket :"
        '
        'txtAPPT
        '
        Me.txtAPPT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAPPT.Location = New System.Drawing.Point(155, 34)
        Me.txtAPPT.Name = "txtAPPT"
        Me.txtAPPT.Size = New System.Drawing.Size(100, 26)
        Me.txtAPPT.TabIndex = 2
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtCTS)
        Me.GroupBox2.Controls.Add(Me.txtCPPT)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.GroupBox2.Location = New System.Drawing.Point(291, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(291, 133)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Child Ticket Sales"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(45, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 20)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Tickets sold :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(126, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Price Per Ticket :"
        '
        'txtCTS
        '
        Me.txtCTS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCTS.Location = New System.Drawing.Point(168, 78)
        Me.txtCTS.Name = "txtCTS"
        Me.txtCTS.Size = New System.Drawing.Size(100, 26)
        Me.txtCTS.TabIndex = 8
        '
        'txtCPPT
        '
        Me.txtCPPT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCPPT.Location = New System.Drawing.Point(168, 36)
        Me.txtCPPT.Name = "txtCPPT"
        Me.txtCPPT.Size = New System.Drawing.Size(100, 26)
        Me.txtCPPT.TabIndex = 6
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lblTGR)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.lblGCTS)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.lblGATS)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 151)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(273, 189)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Gross Ticket Revenue"
        '
        'lblTGR
        '
        Me.lblTGR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTGR.Location = New System.Drawing.Point(155, 133)
        Me.lblTGR.Name = "lblTGR"
        Me.lblTGR.Size = New System.Drawing.Size(100, 26)
        Me.lblTGR.TabIndex = 11
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label9.Location = New System.Drawing.Point(6, 114)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(150, 45)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Total Gross Revenue for Ticket Sales :"
        '
        'lblGCTS
        '
        Me.lblGCTS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGCTS.Location = New System.Drawing.Point(155, 70)
        Me.lblGCTS.Name = "lblGCTS"
        Me.lblGCTS.Size = New System.Drawing.Size(100, 26)
        Me.lblGCTS.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label7.Location = New System.Drawing.Point(6, 77)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(140, 18)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Child Tickets sales :"
        '
        'lblGATS
        '
        Me.lblGATS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGATS.Location = New System.Drawing.Point(155, 31)
        Me.lblGATS.Name = "lblGATS"
        Me.lblGATS.Size = New System.Drawing.Size(100, 26)
        Me.lblGATS.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label5.Location = New System.Drawing.Point(6, 38)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(139, 18)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Adult Tickets sales :"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.lblTNR)
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.lblNATS)
        Me.GroupBox4.Controls.Add(Me.lblNCTS)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.GroupBox4.Location = New System.Drawing.Point(291, 151)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(291, 189)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Net Ticket Revenue"
        '
        'lblTNR
        '
        Me.lblTNR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTNR.Location = New System.Drawing.Point(168, 133)
        Me.lblTNR.Name = "lblTNR"
        Me.lblTNR.Size = New System.Drawing.Size(100, 26)
        Me.lblTNR.TabIndex = 17
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label13.Location = New System.Drawing.Point(19, 38)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(139, 18)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Adult Tickets sales :"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label8.Location = New System.Drawing.Point(19, 114)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(149, 45)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Total Net Revenue for Ticket Sales :"
        '
        'lblNATS
        '
        Me.lblNATS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNATS.Location = New System.Drawing.Point(168, 31)
        Me.lblNATS.Name = "lblNATS"
        Me.lblNATS.Size = New System.Drawing.Size(100, 26)
        Me.lblNATS.TabIndex = 13
        '
        'lblNCTS
        '
        Me.lblNCTS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNCTS.Location = New System.Drawing.Point(168, 70)
        Me.lblNCTS.Name = "lblNCTS"
        Me.lblNCTS.Size = New System.Drawing.Size(100, 26)
        Me.lblNCTS.TabIndex = 15
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label11.Location = New System.Drawing.Point(19, 77)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(140, 18)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Child Tickets sales :"
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnCalculate.Location = New System.Drawing.Point(12, 374)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(172, 49)
        Me.btnCalculate.TabIndex = 8
        Me.btnCalculate.Text = "C&alculate Ticket Revenue"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnClear.Location = New System.Drawing.Point(204, 374)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(172, 49)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnExit.Location = New System.Drawing.Point(398, 374)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(172, 49)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(594, 467)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtATS As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtAPPT As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtCTS As TextBox
    Friend WithEvents txtCPPT As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lblTGR As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblGCTS As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblGATS As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents lblTNR As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblNATS As Label
    Friend WithEvents lblNCTS As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
