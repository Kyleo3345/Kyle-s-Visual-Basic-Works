﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decGATS As Decimal
        Dim decGCTS As Decimal
        Dim decTGR As Decimal
        Dim decNATS As Decimal
        Dim decNCTS As Decimal
        Dim decTNR As Decimal

        Try
            decGATS = CDec(txtATS.Text) * CDec(txtAPPT.Text)
            decGCTS = CDec(txtCPPT.Text) * CDec(txtCTS.Text)
            lblGATS.Text = decGATS.ToString("c")
            lblGCTS.Text = decGCTS.ToString("c")
            decTGR = decGATS + decGCTS
            lblTGR.Text = decTGR.ToString("c")

            decNATS = CDec(txtATS.Text) * CDec(txtAPPT.Text)
            decNCTS = CDec(txtCPPT.Text) * CDec(txtCTS.Text)
            lblNATS.Text = decNATS.ToString("c")
            lblNCTS.Text = decNCTS.ToString("c")
            decTNR = (decNATS * 0.2) + (decNCTS * 0.2)
            lblTNR.Text = decTNR.ToString("c")

        Catch ex As Exception
            MessageBox.Show("There has to be numeric input in all four boxes!")
        End Try

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtAPPT.Clear()
        txtATS.Clear()
        txtCPPT.Clear()
        txtCTS.Clear()

        lblGATS.Text = String.Empty
        lblGCTS.Text = String.Empty
        lblNATS.Text = String.Empty
        lblNCTS.Text = String.Empty
        lblTGR.Text = String.Empty
        lblTNR.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
