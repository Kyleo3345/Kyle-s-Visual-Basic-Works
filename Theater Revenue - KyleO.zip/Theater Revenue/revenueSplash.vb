﻿Public Class revenueSplash
    Private Sub tmrSplash_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrSplash.Tick
        tmrSplash.Enabled = False
        Me.Close()
    End Sub

    Private Sub revenueSplash_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class