﻿Public Class Form1
    Const MIN_COUNT As Integer = 5
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim rand As New Random
        Dim intArray(121) As Integer
        Dim intNumVals = rand.Next(6) + MIN_COUNT
        Array.Resize(intArray, intNumVals + 1)

        For i As Integer = 1 To intNumVals
            intArray(i) = rand.Next(100) + 1
        Next
        Array.Sort(intArray)

        Dim str As String = ""
        For i As Integer = 1 To intNumVals
            str &= intArray(i).ToString() + ","
        Next

        lblArray.Text = str
        Dim median As Double = 0.0

        Dim midPoint As Integer = intNumVals \ 2
        If intNumVals Mod 2 = 0 Then
            median = (intArray(midPoint) + intArray(midPoint + 1)) / 2.0
        Else
            median = intArray(midPoint + 1)
        End If
        lblMedVal.Text = median.ToString("n")
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub

End Class
