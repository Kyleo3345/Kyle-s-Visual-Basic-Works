﻿Public Class Form1

    'Kyle Osterman
    'CMPSC224

    Private Sub btnClassSessionNum_Click(sender As Object, e As EventArgs) Handles btnClassSessionNum.Click
        Dim ClassInput As Integer
        ClassInput = CInt(txtClassSessNum.Text)
        lstClassSessNum.Items.Add(ClassInput)
    End Sub

    Private Sub btnStudentNames_Click(sender As Object, e As EventArgs) Handles btnStudentNames.Click
        Dim StudentInput As String
        StudentInput = CStr(txtStudentNames.Text)
        lstStudentNames.Items.Add(StudentInput)
    End Sub

    Private Sub btnStudentParentContact_Click(sender As Object, e As EventArgs) Handles btnStudentParentContact.Click
        Dim ParentContactInput As String
        ParentContactInput = CStr(txtStudParContact.Text)
        lstParentContacts.Items.Add(ParentContactInput)
    End Sub

    Private Sub btnMedAlerts_Click(sender As Object, e As EventArgs) Handles btnMedAlerts.Click
        Dim MedicalInput As String
        MedicalInput = CStr(txtMedAlert.Text)
        lstMedicalAlerts.Items.Add(MedicalInput)
    End Sub

    Private Sub btnNumofAbsences_Click(sender As Object, e As EventArgs) Handles btnNumofAbsences.Click
        Dim AbsencesInput As String
        AbsencesInput = CStr(txtNumofAbsences.Text)
        lstAbsences.Items.Add(AbsencesInput)
    End Sub

    Private Sub btnAvgGrade_Click(sender As Object, e As EventArgs) Handles btnAvgGrade.Click
        Dim AvgGrade As String
        AvgGrade = CStr(txtGradeAvg.Text)
        lstGradeAvg.Items.Add(AvgGrade)
    End Sub

    Private Sub btnGpD_Click(sender As Object, e As EventArgs) Handles btnGpD.Click
        Dim GradePerDay As String
        GradePerDay = CStr(txtGpD.Text)
        lstGpd.Items.Add(GradePerDay)
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtClassSessNum.Text = String.Empty
        txtStudentNames.Text = String.Empty
        txtGpD.Text = String.Empty
        txtGradeAvg.Text = String.Empty
        txtMedAlert.Text = String.Empty
        txtNumofAbsences.Text = String.Empty
        txtStudParContact.Text = String.Empty
        lstAbsences.Items.Clear()
        lstClassSessNum.Items.Clear()
        lstGpd.Items.Clear()
        lstGradeAvg.Items.Clear()
        lstMedicalAlerts.Items.Clear()
        lstParentContacts.Items.Clear()
        lstStudentNames.Items.Clear()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class


