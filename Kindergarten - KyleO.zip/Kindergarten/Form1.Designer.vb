﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnMedAlerts = New System.Windows.Forms.Button()
        Me.btnClassSessionNum = New System.Windows.Forms.Button()
        Me.btnStudentNames = New System.Windows.Forms.Button()
        Me.btnStudentParentContact = New System.Windows.Forms.Button()
        Me.btnAvgGrade = New System.Windows.Forms.Button()
        Me.btnNumofAbsences = New System.Windows.Forms.Button()
        Me.txtClassSessNum = New System.Windows.Forms.TextBox()
        Me.txtStudentNames = New System.Windows.Forms.TextBox()
        Me.txtStudParContact = New System.Windows.Forms.TextBox()
        Me.txtMedAlert = New System.Windows.Forms.TextBox()
        Me.txtNumofAbsences = New System.Windows.Forms.TextBox()
        Me.txtGradeAvg = New System.Windows.Forms.TextBox()
        Me.lstClassSessNum = New System.Windows.Forms.ListBox()
        Me.lstStudentNames = New System.Windows.Forms.ListBox()
        Me.lstParentContacts = New System.Windows.Forms.ListBox()
        Me.lstMedicalAlerts = New System.Windows.Forms.ListBox()
        Me.lstAbsences = New System.Windows.Forms.ListBox()
        Me.lstGradeAvg = New System.Windows.Forms.ListBox()
        Me.lstGpd = New System.Windows.Forms.ListBox()
        Me.btnGpD = New System.Windows.Forms.Button()
        Me.txtGpD = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnMedAlerts
        '
        Me.btnMedAlerts.BackColor = System.Drawing.SystemColors.Control
        Me.btnMedAlerts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMedAlerts.Location = New System.Drawing.Point(28, 405)
        Me.btnMedAlerts.Name = "btnMedAlerts"
        Me.btnMedAlerts.Size = New System.Drawing.Size(125, 36)
        Me.btnMedAlerts.TabIndex = 25
        Me.btnMedAlerts.Text = "Medical alerts"
        Me.btnMedAlerts.UseVisualStyleBackColor = False
        '
        'btnClassSessionNum
        '
        Me.btnClassSessionNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClassSessionNum.Location = New System.Drawing.Point(30, 65)
        Me.btnClassSessionNum.Name = "btnClassSessionNum"
        Me.btnClassSessionNum.Size = New System.Drawing.Size(123, 53)
        Me.btnClassSessionNum.TabIndex = 26
        Me.btnClassSessionNum.Text = "Class Session Number"
        Me.btnClassSessionNum.UseVisualStyleBackColor = True
        '
        'btnStudentNames
        '
        Me.btnStudentNames.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStudentNames.Location = New System.Drawing.Point(223, 81)
        Me.btnStudentNames.Name = "btnStudentNames"
        Me.btnStudentNames.Size = New System.Drawing.Size(134, 39)
        Me.btnStudentNames.TabIndex = 28
        Me.btnStudentNames.Text = "Student Names"
        Me.btnStudentNames.UseVisualStyleBackColor = True
        '
        'btnStudentParentContact
        '
        Me.btnStudentParentContact.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStudentParentContact.Location = New System.Drawing.Point(459, 74)
        Me.btnStudentParentContact.Name = "btnStudentParentContact"
        Me.btnStudentParentContact.Size = New System.Drawing.Size(132, 53)
        Me.btnStudentParentContact.TabIndex = 30
        Me.btnStudentParentContact.Text = "Student Parent Contacts"
        Me.btnStudentParentContact.UseVisualStyleBackColor = True
        '
        'btnAvgGrade
        '
        Me.btnAvgGrade.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAvgGrade.Location = New System.Drawing.Point(459, 397)
        Me.btnAvgGrade.Name = "btnAvgGrade"
        Me.btnAvgGrade.Size = New System.Drawing.Size(125, 44)
        Me.btnAvgGrade.TabIndex = 32
        Me.btnAvgGrade.Text = "Grade Average"
        Me.btnAvgGrade.UseVisualStyleBackColor = True
        '
        'btnNumofAbsences
        '
        Me.btnNumofAbsences.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNumofAbsences.Location = New System.Drawing.Point(211, 405)
        Me.btnNumofAbsences.Name = "btnNumofAbsences"
        Me.btnNumofAbsences.Size = New System.Drawing.Size(170, 45)
        Me.btnNumofAbsences.TabIndex = 34
        Me.btnNumofAbsences.Text = "Number of Absences"
        Me.btnNumofAbsences.UseVisualStyleBackColor = True
        '
        'txtClassSessNum
        '
        Me.txtClassSessNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClassSessNum.Location = New System.Drawing.Point(12, 38)
        Me.txtClassSessNum.Name = "txtClassSessNum"
        Me.txtClassSessNum.Size = New System.Drawing.Size(170, 26)
        Me.txtClassSessNum.TabIndex = 36
        '
        'txtStudentNames
        '
        Me.txtStudentNames.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentNames.Location = New System.Drawing.Point(197, 39)
        Me.txtStudentNames.Name = "txtStudentNames"
        Me.txtStudentNames.Size = New System.Drawing.Size(197, 26)
        Me.txtStudentNames.TabIndex = 37
        '
        'txtStudParContact
        '
        Me.txtStudParContact.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudParContact.Location = New System.Drawing.Point(428, 38)
        Me.txtStudParContact.Name = "txtStudParContact"
        Me.txtStudParContact.Size = New System.Drawing.Size(194, 26)
        Me.txtStudParContact.TabIndex = 38
        '
        'txtMedAlert
        '
        Me.txtMedAlert.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMedAlert.Location = New System.Drawing.Point(12, 373)
        Me.txtMedAlert.Name = "txtMedAlert"
        Me.txtMedAlert.Size = New System.Drawing.Size(159, 26)
        Me.txtMedAlert.TabIndex = 39
        '
        'txtNumofAbsences
        '
        Me.txtNumofAbsences.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumofAbsences.Location = New System.Drawing.Point(211, 373)
        Me.txtNumofAbsences.Name = "txtNumofAbsences"
        Me.txtNumofAbsences.Size = New System.Drawing.Size(159, 26)
        Me.txtNumofAbsences.TabIndex = 40
        '
        'txtGradeAvg
        '
        Me.txtGradeAvg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGradeAvg.Location = New System.Drawing.Point(435, 365)
        Me.txtGradeAvg.Name = "txtGradeAvg"
        Me.txtGradeAvg.Size = New System.Drawing.Size(170, 26)
        Me.txtGradeAvg.TabIndex = 41
        '
        'lstClassSessNum
        '
        Me.lstClassSessNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstClassSessNum.FormattingEnabled = True
        Me.lstClassSessNum.ItemHeight = 20
        Me.lstClassSessNum.Location = New System.Drawing.Point(12, 134)
        Me.lstClassSessNum.Name = "lstClassSessNum"
        Me.lstClassSessNum.Size = New System.Drawing.Size(161, 184)
        Me.lstClassSessNum.TabIndex = 42
        '
        'lstStudentNames
        '
        Me.lstStudentNames.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstStudentNames.FormattingEnabled = True
        Me.lstStudentNames.ItemHeight = 20
        Me.lstStudentNames.Location = New System.Drawing.Point(211, 134)
        Me.lstStudentNames.Name = "lstStudentNames"
        Me.lstStudentNames.Size = New System.Drawing.Size(161, 184)
        Me.lstStudentNames.TabIndex = 43
        '
        'lstParentContacts
        '
        Me.lstParentContacts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstParentContacts.FormattingEnabled = True
        Me.lstParentContacts.ItemHeight = 20
        Me.lstParentContacts.Location = New System.Drawing.Point(413, 134)
        Me.lstParentContacts.Name = "lstParentContacts"
        Me.lstParentContacts.Size = New System.Drawing.Size(240, 184)
        Me.lstParentContacts.TabIndex = 44
        '
        'lstMedicalAlerts
        '
        Me.lstMedicalAlerts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstMedicalAlerts.FormattingEnabled = True
        Me.lstMedicalAlerts.ItemHeight = 20
        Me.lstMedicalAlerts.Location = New System.Drawing.Point(12, 462)
        Me.lstMedicalAlerts.Name = "lstMedicalAlerts"
        Me.lstMedicalAlerts.Size = New System.Drawing.Size(161, 184)
        Me.lstMedicalAlerts.TabIndex = 45
        '
        'lstAbsences
        '
        Me.lstAbsences.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstAbsences.FormattingEnabled = True
        Me.lstAbsences.ItemHeight = 20
        Me.lstAbsences.Location = New System.Drawing.Point(211, 462)
        Me.lstAbsences.Name = "lstAbsences"
        Me.lstAbsences.Size = New System.Drawing.Size(161, 184)
        Me.lstAbsences.TabIndex = 46
        '
        'lstGradeAvg
        '
        Me.lstGradeAvg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstGradeAvg.FormattingEnabled = True
        Me.lstGradeAvg.ItemHeight = 20
        Me.lstGradeAvg.Location = New System.Drawing.Point(444, 462)
        Me.lstGradeAvg.Name = "lstGradeAvg"
        Me.lstGradeAvg.Size = New System.Drawing.Size(161, 184)
        Me.lstGradeAvg.TabIndex = 47
        '
        'lstGpd
        '
        Me.lstGpd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstGpd.FormattingEnabled = True
        Me.lstGpd.ItemHeight = 20
        Me.lstGpd.Location = New System.Drawing.Point(706, 147)
        Me.lstGpd.Name = "lstGpd"
        Me.lstGpd.Size = New System.Drawing.Size(161, 224)
        Me.lstGpd.TabIndex = 48
        '
        'btnGpD
        '
        Me.btnGpD.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGpD.Location = New System.Drawing.Point(720, 99)
        Me.btnGpD.Name = "btnGpD"
        Me.btnGpD.Size = New System.Drawing.Size(132, 42)
        Me.btnGpD.TabIndex = 49
        Me.btnGpD.Text = "Grades per Day"
        Me.btnGpD.UseVisualStyleBackColor = True
        '
        'txtGpD
        '
        Me.txtGpD.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGpD.Location = New System.Drawing.Point(685, 67)
        Me.txtGpD.Name = "txtGpD"
        Me.txtGpD.Size = New System.Drawing.Size(194, 26)
        Me.txtGpD.TabIndex = 50
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnExit.Location = New System.Drawing.Point(706, 597)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(172, 49)
        Me.btnExit.TabIndex = 52
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnClear.Location = New System.Drawing.Point(707, 516)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(172, 49)
        Me.btnClear.TabIndex = 51
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 658)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.txtGpD)
        Me.Controls.Add(Me.btnGpD)
        Me.Controls.Add(Me.lstGpd)
        Me.Controls.Add(Me.lstGradeAvg)
        Me.Controls.Add(Me.lstAbsences)
        Me.Controls.Add(Me.lstMedicalAlerts)
        Me.Controls.Add(Me.lstParentContacts)
        Me.Controls.Add(Me.lstStudentNames)
        Me.Controls.Add(Me.lstClassSessNum)
        Me.Controls.Add(Me.txtGradeAvg)
        Me.Controls.Add(Me.txtNumofAbsences)
        Me.Controls.Add(Me.txtMedAlert)
        Me.Controls.Add(Me.txtStudParContact)
        Me.Controls.Add(Me.txtStudentNames)
        Me.Controls.Add(Me.txtClassSessNum)
        Me.Controls.Add(Me.btnNumofAbsences)
        Me.Controls.Add(Me.btnAvgGrade)
        Me.Controls.Add(Me.btnStudentParentContact)
        Me.Controls.Add(Me.btnStudentNames)
        Me.Controls.Add(Me.btnClassSessionNum)
        Me.Controls.Add(Me.btnMedAlerts)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnMedAlerts As Button
    Friend WithEvents btnClassSessionNum As Button
    Friend WithEvents btnStudentNames As Button
    Friend WithEvents btnStudentParentContact As Button
    Friend WithEvents btnAvgGrade As Button
    Friend WithEvents btnNumofAbsences As Button
    Friend WithEvents txtClassSessNum As TextBox
    Friend WithEvents txtStudentNames As TextBox
    Friend WithEvents txtStudParContact As TextBox
    Friend WithEvents txtMedAlert As TextBox
    Friend WithEvents txtNumofAbsences As TextBox
    Friend WithEvents txtGradeAvg As TextBox
    Friend WithEvents lstClassSessNum As ListBox
    Friend WithEvents lstStudentNames As ListBox
    Friend WithEvents lstParentContacts As ListBox
    Friend WithEvents lstMedicalAlerts As ListBox
    Friend WithEvents lstAbsences As ListBox
    Friend WithEvents lstGradeAvg As ListBox
    Friend WithEvents lstGpd As ListBox
    Friend WithEvents btnGpD As Button
    Friend WithEvents txtGpD As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
End Class
