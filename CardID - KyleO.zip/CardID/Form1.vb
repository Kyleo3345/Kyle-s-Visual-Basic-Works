﻿Public Class CardID
    Private Sub pic10diamonds_Click() Handles pic10diamonds.Click
        lblCard.Text = "10 of Diamonds"
    End Sub
    Private Sub pic3spades_Click() Handles pic3spades.Click
        lblCard.Text = "3 of Spades"
    End Sub
    Private Sub pic5hearts_Click() Handles pic5hearts.Click
        lblCard.Text = "5 of Hearts"
    End Sub
    Private Sub picAceofclubs_Click() Handles picAceofclubs.Click
        lblCard.Text = "Ace of Clubs"
    End Sub
    Private Sub picKingofdiamonds_Click() Handles picKingofdiamonds.Click
        lblCard.Text = "King of Diamonds"
    End Sub
    Private Sub btnExit_Click() Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        frmSplash.ShowDialog()
    End Sub
End Class
