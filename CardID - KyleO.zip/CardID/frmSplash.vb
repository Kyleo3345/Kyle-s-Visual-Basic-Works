﻿Public Class frmSplash
    Private Sub tmrSplash_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrSplash.Tick
        tmrSplash.Enabled = True
        Me.Close()
    End Sub
End Class