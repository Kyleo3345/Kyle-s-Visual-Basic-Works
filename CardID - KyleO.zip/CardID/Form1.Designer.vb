﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CardID
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pic10diamonds = New System.Windows.Forms.PictureBox()
        Me.pic3spades = New System.Windows.Forms.PictureBox()
        Me.pic5hearts = New System.Windows.Forms.PictureBox()
        Me.picAceofclubs = New System.Windows.Forms.PictureBox()
        Me.picKingofdiamonds = New System.Windows.Forms.PictureBox()
        Me.lblCard = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.pic10diamonds, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic3spades, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic5hearts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAceofclubs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picKingofdiamonds, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic10diamonds
        '
        Me.pic10diamonds.Image = Global.CardID.My.Resources.Resources._10_Diamonds
        Me.pic10diamonds.Location = New System.Drawing.Point(27, 64)
        Me.pic10diamonds.Name = "pic10diamonds"
        Me.pic10diamonds.Size = New System.Drawing.Size(127, 171)
        Me.pic10diamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic10diamonds.TabIndex = 0
        Me.pic10diamonds.TabStop = False
        '
        'pic3spades
        '
        Me.pic3spades.Image = Global.CardID.My.Resources.Resources._3_Spades
        Me.pic3spades.Location = New System.Drawing.Point(177, 64)
        Me.pic3spades.Name = "pic3spades"
        Me.pic3spades.Size = New System.Drawing.Size(127, 171)
        Me.pic3spades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic3spades.TabIndex = 1
        Me.pic3spades.TabStop = False
        '
        'pic5hearts
        '
        Me.pic5hearts.Image = Global.CardID.My.Resources.Resources._5_Hearts
        Me.pic5hearts.Location = New System.Drawing.Point(329, 64)
        Me.pic5hearts.Name = "pic5hearts"
        Me.pic5hearts.Size = New System.Drawing.Size(127, 171)
        Me.pic5hearts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic5hearts.TabIndex = 2
        Me.pic5hearts.TabStop = False
        '
        'picAceofclubs
        '
        Me.picAceofclubs.Image = Global.CardID.My.Resources.Resources.Ace_Clubs
        Me.picAceofclubs.Location = New System.Drawing.Point(484, 64)
        Me.picAceofclubs.Name = "picAceofclubs"
        Me.picAceofclubs.Size = New System.Drawing.Size(127, 171)
        Me.picAceofclubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAceofclubs.TabIndex = 3
        Me.picAceofclubs.TabStop = False
        '
        'picKingofdiamonds
        '
        Me.picKingofdiamonds.Image = Global.CardID.My.Resources.Resources.King_Diamonds
        Me.picKingofdiamonds.Location = New System.Drawing.Point(635, 64)
        Me.picKingofdiamonds.Name = "picKingofdiamonds"
        Me.picKingofdiamonds.Size = New System.Drawing.Size(127, 171)
        Me.picKingofdiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picKingofdiamonds.TabIndex = 4
        Me.picKingofdiamonds.TabStop = False
        '
        'lblCard
        '
        Me.lblCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCard.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.lblCard.Location = New System.Drawing.Point(195, 328)
        Me.lblCard.Name = "lblCard"
        Me.lblCard.Size = New System.Drawing.Size(389, 32)
        Me.lblCard.TabIndex = 5
        Me.lblCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.btnExit.Location = New System.Drawing.Point(641, 391)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(144, 51)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Close"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'CardID
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblCard)
        Me.Controls.Add(Me.picKingofdiamonds)
        Me.Controls.Add(Me.picAceofclubs)
        Me.Controls.Add(Me.pic5hearts)
        Me.Controls.Add(Me.pic3spades)
        Me.Controls.Add(Me.pic10diamonds)
        Me.Name = "CardID"
        Me.Text = "CardID"
        CType(Me.pic10diamonds, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic3spades, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic5hearts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAceofclubs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picKingofdiamonds, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pic10diamonds As PictureBox
    Friend WithEvents pic3spades As PictureBox
    Friend WithEvents pic5hearts As PictureBox
    Friend WithEvents picAceofclubs As PictureBox
    Friend WithEvents picKingofdiamonds As PictureBox
    Friend WithEvents lblCard As Label
    Friend WithEvents btnExit As Button
End Class
