﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Public Class Form1
    Private dtKayaks As DataTable
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lstKayakTypes.DataSource = GetNameData()
        lstKayakTypes.DisplayMember = "Name"
        lblOutput = GetDescData()

    End Sub

    Private Function GetNameData() As DataTable
        dtKayaks = New DataTable
        Dim connection As String = ConfigurationManager.ConnectionStrings("KayakDB").ConnectionString

        Using conn As New SqlConnection(connection)
            Using cmd As New SqlCommand("SELECT Name FROM KayakTypes", conn)
                conn.Open()
                Dim reader As SqlDataReader = cmd.ExecuteReader
                dtKayaks.Load(reader)
            End Using
        End Using

        Return dtKayaks

    End Function
    Private Function GetDescData()

        Dim connection As String = ConfigurationManager.ConnectionStrings("KayakDB").ConnectionString
        Dim conn As New SqlConnection(connection)
        conn.Open()
        Dim cmd As New SqlCommand("SELECT Description FROM KayakTypes", conn)
        Dim reader As SqlDataReader
        reader = cmd.ExecuteReader

        If reader.Read Then
            lblOutput.Text = reader("Description").ToString()
        End If

    End Function
End Class
