﻿Public Class Form1

    Private Const decOilchange As Decimal = 36D
    Private Const decLubechange As Decimal = 28D
    Private Const decRadFlush As Decimal = 50D
    Private Const decTransFlush As Decimal = 120D
    Private Const decInspection As Decimal = 15D
    Private Const decReplaceMuff As Decimal = 200D
    Private Const decTireRotate As Decimal = 20D
    Private Const decLaborPrice As Decimal = 60D
    Private m_decParts As Decimal = 0D
    Private m_decLabor As Decimal = 0D

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decOilLubeTotal As Decimal = CalcOilLubeCharges()
        Dim decFlushTotal As Decimal = CalcFlushCharges()
        Dim decMiscTotal As Decimal = CalcMiscCharges()
        Dim decServiceandLabor As Decimal = CalcSvcandLabor(decOilLubeTotal, decFlushTotal, decMiscTotal)
        Dim decTax As Decimal = CalcTax()
        Dim decTotalFees As Decimal = decServiceandLabor + m_decParts + decTax
        Dim decParts_Labor As Decimal = CalcPartsAndLabor()

        lblSaL.Text = decServiceandLabor.ToString("C")
        lblParts.Text = m_decParts.ToString("C")
        lblTax.Text = decTax.ToString("C")
        lblTotal.Text = decTotalFees.ToString("C")

    End Sub

    Function CalcPartsAndLabor() As Boolean
        Const sngMIN2Hour As Single = 60D
        Dim decPartsCost As Decimal = 0D
        Dim sngMinutes As Single = 0F

        Try
            decPartsCost = CDec(txtParts.Text)
            sngMinutes = CSng(txtLabor.Text)
        Catch ex As Exception
            MessageBox.Show("Invalid!!", CStr(MessageBoxButtons.OK), CType(MessageBoxIcon.Error, MessageBoxButtons))
            txtParts.Clear()
            txtLabor.Clear()
            txtParts.Focus()
        End Try
        m_decParts = decPartsCost
        m_decLabor = CDec(sngMinutes / sngMIN2Hour * decLaborPrice)
        Return CalcPartsAndLabor
    End Function

    Function CalcOilLubeCharges() As Decimal
        Dim decOilLubeTotal As Decimal = 0D
        If chkOil.Checked Then
            decOilLubeTotal += decOilchange
        End If
        If chkLube.Checked Then
            decOilLubeTotal += decLubechange
        End If
        Return decOilLubeTotal
    End Function

    Function CalcFlushCharges() As Decimal
        Dim decFlushTotal As Decimal = 0D
        If chkRad.Checked Then
            decFlushTotal += decRadFlush
        End If
        If chkTrans.Checked Then
            decFlushTotal += decTransFlush
        End If
        Return decFlushTotal
    End Function

    Function CalcMiscCharges() As Decimal
        Dim decMiscTotal As Decimal = 0D
        If chkInspect.Checked Then
            decMiscTotal += decInspection
        End If
        If chkRepMuff.Checked Then
            decMiscTotal += decReplaceMuff
        End If
        If chkTire.Checked Then
            decMiscTotal += decTireRotate
        End If
        Return decMiscTotal
    End Function

    Function CalcSvcandLabor(decOilLubeTotal, decFlushTotal, decMiscTotal)
        Dim decTotal As Decimal
        decTotal = decOilLubeTotal + decFlushTotal + decMiscTotal + m_decLabor
        Return decTotal
    End Function

    Function CalcTax() As Decimal
        Const decTaxRate As Decimal = 0.1D
        Dim decTax As Decimal = m_decParts * decTaxRate
        Return decTax
    End Function

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        m_decLabor = 0
        m_decParts = 0
        txtLabor.Text = "0"
        txtParts.Text = "0"
        chkInspect.Checked = False
        chkLube.Checked = False
        chkOil.Checked = False
        chkRad.Checked = False
        chkRepMuff.Checked = False
        chkTire.Checked = False
        chkTrans.Checked = False
        lblParts.Text = String.Empty
        lblSaL.Text = String.Empty
        lblTax.Text = String.Empty
        lblTotal.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
