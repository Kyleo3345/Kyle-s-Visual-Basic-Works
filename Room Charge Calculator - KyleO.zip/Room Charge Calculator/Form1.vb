﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblDate.Text = Now.ToString("D")
        lblTime.Text = Now.ToString("T")
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decRoomCharges As Decimal
        Dim decAddCharges As Decimal
        Dim decSubtotal As Decimal
        Dim decTax As Decimal
        Dim decTotal As Decimal
        Const decTax_rate As Decimal = 0.08D

        Try
            decRoomCharges = CDec(txtNoNights.Text) * CDec(txtNightCharge.Text)
            lblRoomCharges.Text = decRoomCharges.ToString("c")

            decAddCharges = CDec(txtRoomSer.Text) + CDec(txtPhone.Text) + CDec(txtMisc.Text)
            lblAddCharges.Text = decAddCharges.ToString("c")

            decSubtotal = decRoomCharges + decAddCharges
            lblSubtotal.Text = decSubtotal.ToString("c")

            decTax = decSubtotal * decTax_rate
            lblTaxes.Text = decTax.ToString("c")

            decTotal = decSubtotal + decTax
            lblTotal.Text = decTotal.ToString("c")

        Catch ex As Exception
            MessageBox.Show("All must be valid numeric values!")
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtMisc.Clear()
        txtNightCharge.Clear()
        txtNoNights.Clear()
        txtPhone.Clear()
        txtRoomSer.Clear()

        lblAddCharges.Text = String.Empty
        lblRoomCharges.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblTaxes.Text = String.Empty
        lblTotal.Text = String.Empty

        lblDate.Text = Now.ToString("D")
        lblTime.Text = Now.ToString("T")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
