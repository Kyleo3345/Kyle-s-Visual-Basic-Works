﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radOneTimePur = New System.Windows.Forms.RadioButton()
        Me.radYearLic = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkCloudBack = New System.Windows.Forms.CheckBox()
        Me.chkOnSiteTrain = New System.Windows.Forms.CheckBox()
        Me.chkLvl3Tech = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblCostoSL = New System.Windows.Forms.Label()
        Me.lblCostoOF = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radOneTimePur)
        Me.GroupBox1.Controls.Add(Me.radYearLic)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(184, 139)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Licensing Options"
        '
        'radOneTimePur
        '
        Me.radOneTimePur.AutoSize = True
        Me.radOneTimePur.Location = New System.Drawing.Point(6, 79)
        Me.radOneTimePur.Name = "radOneTimePur"
        Me.radOneTimePur.Size = New System.Drawing.Size(153, 21)
        Me.radOneTimePur.TabIndex = 1
        Me.radOneTimePur.TabStop = True
        Me.radOneTimePur.Text = "One-Time Purchase"
        Me.radOneTimePur.UseVisualStyleBackColor = True
        '
        'radYearLic
        '
        Me.radYearLic.AutoSize = True
        Me.radYearLic.Location = New System.Drawing.Point(6, 43)
        Me.radYearLic.Name = "radYearLic"
        Me.radYearLic.Size = New System.Drawing.Size(119, 21)
        Me.radYearLic.TabIndex = 0
        Me.radYearLic.TabStop = True
        Me.radYearLic.Text = "Yearly License"
        Me.radYearLic.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkCloudBack)
        Me.GroupBox2.Controls.Add(Me.chkOnSiteTrain)
        Me.GroupBox2.Controls.Add(Me.chkLvl3Tech)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.GroupBox2.Location = New System.Drawing.Point(275, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(220, 139)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Optional Features (Yearly)"
        '
        'chkCloudBack
        '
        Me.chkCloudBack.AutoSize = True
        Me.chkCloudBack.Location = New System.Drawing.Point(6, 86)
        Me.chkCloudBack.Name = "chkCloudBack"
        Me.chkCloudBack.Size = New System.Drawing.Size(114, 21)
        Me.chkCloudBack.TabIndex = 2
        Me.chkCloudBack.Text = "Cloud Backup"
        Me.chkCloudBack.UseVisualStyleBackColor = True
        '
        'chkOnSiteTrain
        '
        Me.chkOnSiteTrain.AutoSize = True
        Me.chkOnSiteTrain.Location = New System.Drawing.Point(6, 59)
        Me.chkOnSiteTrain.Name = "chkOnSiteTrain"
        Me.chkOnSiteTrain.Size = New System.Drawing.Size(131, 21)
        Me.chkOnSiteTrain.TabIndex = 1
        Me.chkOnSiteTrain.Text = "On-Site Training"
        Me.chkOnSiteTrain.UseVisualStyleBackColor = True
        '
        'chkLvl3Tech
        '
        Me.chkLvl3Tech.AutoSize = True
        Me.chkLvl3Tech.Location = New System.Drawing.Point(6, 32)
        Me.chkLvl3Tech.Name = "chkLvl3Tech"
        Me.chkLvl3Tech.Size = New System.Drawing.Size(164, 21)
        Me.chkLvl3Tech.TabIndex = 0
        Me.chkLvl3Tech.Text = "Level-3 Tech Support"
        Me.chkLvl3Tech.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(33, 204)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(194, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Cost of software licensing:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(33, 247)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(187, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Cost of optional features:"
        '
        'lblCostoSL
        '
        Me.lblCostoSL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostoSL.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblCostoSL.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblCostoSL.Location = New System.Drawing.Point(268, 207)
        Me.lblCostoSL.Name = "lblCostoSL"
        Me.lblCostoSL.Size = New System.Drawing.Size(128, 17)
        Me.lblCostoSL.TabIndex = 4
        '
        'lblCostoOF
        '
        Me.lblCostoOF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostoOF.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblCostoOF.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblCostoOF.Location = New System.Drawing.Point(268, 250)
        Me.lblCostoOF.Name = "lblCostoOF"
        Me.lblCostoOF.Size = New System.Drawing.Size(128, 17)
        Me.lblCostoOF.TabIndex = 5
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnCalc.Location = New System.Drawing.Point(26, 319)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(145, 48)
        Me.btnCalc.TabIndex = 9
        Me.btnCalc.Text = "C&alculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnClear.Location = New System.Drawing.Point(196, 319)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(145, 48)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnExit.Location = New System.Drawing.Point(361, 319)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(145, 48)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(19, 182)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(442, 107)
        Me.Label3.TabIndex = 12
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(518, 379)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblCostoOF)
        Me.Controls.Add(Me.lblCostoSL)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label3)
        Me.Name = "Form1"
        Me.Text = "Software Sales"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radOneTimePur As RadioButton
    Friend WithEvents radYearLic As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkCloudBack As CheckBox
    Friend WithEvents chkOnSiteTrain As CheckBox
    Friend WithEvents chkLvl3Tech As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblCostoSL As Label
    Friend WithEvents lblCostoOF As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label3 As Label
End Class
