﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim decCostoSL As Decimal
        Dim decCostoOF As Decimal

        Const decYearlyLicense As Decimal = 5000D
        Const decOneTimePur As Decimal = 20000D

        Const decLvl3TechSup As Decimal = 3500D
        Const decOnSiteTrain As Decimal = 2000D
        Const decCloudBackup As Decimal = 300D

        If radYearLic.Checked Then
            decCostoSL = decYearlyLicense
        ElseIf radOneTimePur.Checked Then
            decCostoSL = decOneTimePur
        End If

        lblCostoSL.Text = decCostoSL.ToString("c")

        If chkLvl3Tech.Checked = True Then
            decCostoOF += decLvl3TechSup
        End If

        If chkOnSiteTrain.Checked = True Then
            decCostoOF += decOnSiteTrain
        End If

        If chkCloudBack.Checked = True Then
            decCostoOF += decCloudBackup
        End If

        lblCostoOF.Text = decCostoOF.ToString("c")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        radYearLic.Checked = True
        chkCloudBack.Checked = False
        chkLvl3Tech.Checked = False
        chkOnSiteTrain.Checked = False

        lblCostoOF.Text = String.Empty
        lblCostoSL.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
