﻿Public Class Person

    Private FName As String
    Private LName As String
    Private Address As String
    Private City As String
    Private State As String
    Private Zip As String
    Private Phone As String

    Public Property get_FName() As String
        Get
            Return FName
        End Get
        Set(value As String)
            FName = value
        End Set
    End Property

    Public Property get_LName() As String
        Get
            Return LName
        End Get
        Set(value As String)
            LName = value
        End Set
    End Property

    Public Property get_Address() As String
        Get
            Return Address
        End Get
        Set(value As String)
            Address = value
        End Set
    End Property

    Public Property get_City() As String
        Get
            Return City
        End Get
        Set(value As String)
            City = value
        End Set
    End Property

    Public Property get_State() As String
        Get
            Return State
        End Get
        Set(value As String)
            State = value
        End Set
    End Property

    Public Property get_Zip() As String
        Get
            Return Zip
        End Get
        Set(value As String)
            Zip = value
        End Set
    End Property

    Public Property get_Phone() As String
        Get
            Return Phone
        End Get
        Set(value As String)
            Phone = value
        End Set
    End Property


End Class
