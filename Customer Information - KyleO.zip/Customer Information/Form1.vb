﻿Public Class Form1

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        Dim PersonInfo As New Person

        PersonInfo.get_FName = txtFName.Text
        PersonInfo.get_LName = txtLName.Text
        PersonInfo.get_Address = txtAddress.Text
        PersonInfo.get_City = txtCity.Text
        PersonInfo.get_State = txtState.Text
        PersonInfo.get_Zip = txtZip.Text
        PersonInfo.get_Phone = txtPhone.Text

        lblFName.Text = PersonInfo.get_FName
        lblLName.Text = PersonInfo.get_LName
        lblAddress.Text = PersonInfo.get_Address
        lblCity.Text = PersonInfo.get_City
        lblState.Text = PersonInfo.get_State
        lblZip.Text = PersonInfo.get_Zip
        lblPhone.Text = PersonInfo.get_Phone

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtFName.Text = String.Empty
        txtLName.Text = String.Empty
        txtAddress.Text = String.Empty
        txtCity.Text = String.Empty
        txtState.Text = String.Empty
        txtZip.Text = String.Empty
        txtPhone.Text = String.Empty

        lblFName.Text = String.Empty
        lblLName.Text = String.Empty
        lblAddress.Text = String.Empty
        lblCity.Text = String.Empty
        lblState.Text = String.Empty
        lblZip.Text = String.Empty
        lblPhone.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
