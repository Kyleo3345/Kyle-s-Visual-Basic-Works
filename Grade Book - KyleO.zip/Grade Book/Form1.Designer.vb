﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnTest1 = New System.Windows.Forms.Button()
        Me.btnTest2 = New System.Windows.Forms.Button()
        Me.btnTest3 = New System.Windows.Forms.Button()
        Me.btnTest4 = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.txtTest1 = New System.Windows.Forms.TextBox()
        Me.txtTest2 = New System.Windows.Forms.TextBox()
        Me.txtTest3 = New System.Windows.Forms.TextBox()
        Me.txtTest4 = New System.Windows.Forms.TextBox()
        Me.chkModTest1 = New System.Windows.Forms.CheckBox()
        Me.btnCalcAvg = New System.Windows.Forms.Button()
        Me.chkModTest2 = New System.Windows.Forms.CheckBox()
        Me.chkModTest3 = New System.Windows.Forms.CheckBox()
        Me.chkModTest4 = New System.Windows.Forms.CheckBox()
        Me.lblAvgGradeNum = New System.Windows.Forms.Label()
        Me.btnInputStudent = New System.Windows.Forms.Button()
        Me.txtStudentNameInput = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblTest1Result = New System.Windows.Forms.Label()
        Me.lblTest2Result = New System.Windows.Forms.Label()
        Me.lblTest3Result = New System.Windows.Forms.Label()
        Me.lblTest4Result = New System.Windows.Forms.Label()
        Me.lblAvgGradeLetter = New System.Windows.Forms.Label()
        Me.btnupdate = New System.Windows.Forms.Button()
        Me.lstStudent = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'btnTest1
        '
        Me.btnTest1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTest1.Location = New System.Drawing.Point(7, 72)
        Me.btnTest1.Name = "btnTest1"
        Me.btnTest1.Size = New System.Drawing.Size(112, 47)
        Me.btnTest1.TabIndex = 0
        Me.btnTest1.Text = "Input Test One"
        Me.btnTest1.UseVisualStyleBackColor = True
        '
        'btnTest2
        '
        Me.btnTest2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTest2.Location = New System.Drawing.Point(125, 72)
        Me.btnTest2.Name = "btnTest2"
        Me.btnTest2.Size = New System.Drawing.Size(112, 47)
        Me.btnTest2.TabIndex = 1
        Me.btnTest2.Text = "Input Test Two"
        Me.btnTest2.UseVisualStyleBackColor = True
        '
        'btnTest3
        '
        Me.btnTest3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTest3.Location = New System.Drawing.Point(243, 72)
        Me.btnTest3.Name = "btnTest3"
        Me.btnTest3.Size = New System.Drawing.Size(112, 47)
        Me.btnTest3.TabIndex = 2
        Me.btnTest3.Text = "Input Test Three"
        Me.btnTest3.UseVisualStyleBackColor = True
        '
        'btnTest4
        '
        Me.btnTest4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTest4.Location = New System.Drawing.Point(361, 72)
        Me.btnTest4.Name = "btnTest4"
        Me.btnTest4.Size = New System.Drawing.Size(112, 47)
        Me.btnTest4.TabIndex = 3
        Me.btnTest4.Text = "Input Test Four"
        Me.btnTest4.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(169, 286)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(163, 37)
        Me.btnSubmit.TabIndex = 4
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'lstOutput
        '
        Me.lstOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.ItemHeight = 20
        Me.lstOutput.Location = New System.Drawing.Point(12, 329)
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(538, 224)
        Me.lstOutput.TabIndex = 5
        '
        'txtTest1
        '
        Me.txtTest1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTest1.Location = New System.Drawing.Point(7, 39)
        Me.txtTest1.Name = "txtTest1"
        Me.txtTest1.Size = New System.Drawing.Size(112, 23)
        Me.txtTest1.TabIndex = 6
        '
        'txtTest2
        '
        Me.txtTest2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTest2.Location = New System.Drawing.Point(125, 39)
        Me.txtTest2.Name = "txtTest2"
        Me.txtTest2.Size = New System.Drawing.Size(112, 23)
        Me.txtTest2.TabIndex = 7
        '
        'txtTest3
        '
        Me.txtTest3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTest3.Location = New System.Drawing.Point(243, 39)
        Me.txtTest3.Name = "txtTest3"
        Me.txtTest3.Size = New System.Drawing.Size(112, 23)
        Me.txtTest3.TabIndex = 8
        '
        'txtTest4
        '
        Me.txtTest4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTest4.Location = New System.Drawing.Point(361, 39)
        Me.txtTest4.Name = "txtTest4"
        Me.txtTest4.Size = New System.Drawing.Size(112, 23)
        Me.txtTest4.TabIndex = 9
        '
        'chkModTest1
        '
        Me.chkModTest1.AutoSize = True
        Me.chkModTest1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkModTest1.Location = New System.Drawing.Point(7, 12)
        Me.chkModTest1.Name = "chkModTest1"
        Me.chkModTest1.Size = New System.Drawing.Size(112, 21)
        Me.chkModTest1.TabIndex = 11
        Me.chkModTest1.Text = "Modify Test 1"
        Me.chkModTest1.UseVisualStyleBackColor = True
        '
        'btnCalcAvg
        '
        Me.btnCalcAvg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalcAvg.Location = New System.Drawing.Point(169, 170)
        Me.btnCalcAvg.Name = "btnCalcAvg"
        Me.btnCalcAvg.Size = New System.Drawing.Size(156, 34)
        Me.btnCalcAvg.TabIndex = 15
        Me.btnCalcAvg.Text = "Calculate Avg Grade"
        Me.btnCalcAvg.UseVisualStyleBackColor = True
        '
        'chkModTest2
        '
        Me.chkModTest2.AutoSize = True
        Me.chkModTest2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkModTest2.Location = New System.Drawing.Point(125, 12)
        Me.chkModTest2.Name = "chkModTest2"
        Me.chkModTest2.Size = New System.Drawing.Size(112, 21)
        Me.chkModTest2.TabIndex = 16
        Me.chkModTest2.Text = "Modify Test 2"
        Me.chkModTest2.UseVisualStyleBackColor = True
        '
        'chkModTest3
        '
        Me.chkModTest3.AutoSize = True
        Me.chkModTest3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkModTest3.Location = New System.Drawing.Point(243, 12)
        Me.chkModTest3.Name = "chkModTest3"
        Me.chkModTest3.Size = New System.Drawing.Size(112, 21)
        Me.chkModTest3.TabIndex = 17
        Me.chkModTest3.Text = "Modify Test 3"
        Me.chkModTest3.UseVisualStyleBackColor = True
        '
        'chkModTest4
        '
        Me.chkModTest4.AutoSize = True
        Me.chkModTest4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkModTest4.Location = New System.Drawing.Point(361, 12)
        Me.chkModTest4.Name = "chkModTest4"
        Me.chkModTest4.Size = New System.Drawing.Size(112, 21)
        Me.chkModTest4.TabIndex = 18
        Me.chkModTest4.Text = "Modify Test 4"
        Me.chkModTest4.UseVisualStyleBackColor = True
        '
        'lblAvgGradeNum
        '
        Me.lblAvgGradeNum.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblAvgGradeNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAvgGradeNum.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvgGradeNum.Location = New System.Drawing.Point(151, 225)
        Me.lblAvgGradeNum.Name = "lblAvgGradeNum"
        Me.lblAvgGradeNum.Size = New System.Drawing.Size(96, 39)
        Me.lblAvgGradeNum.TabIndex = 19
        Me.lblAvgGradeNum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnInputStudent
        '
        Me.btnInputStudent.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInputStudent.Location = New System.Drawing.Point(653, 83)
        Me.btnInputStudent.Name = "btnInputStudent"
        Me.btnInputStudent.Size = New System.Drawing.Size(144, 25)
        Me.btnInputStudent.TabIndex = 20
        Me.btnInputStudent.Text = "Input Student Name"
        Me.btnInputStudent.UseVisualStyleBackColor = True
        '
        'txtStudentNameInput
        '
        Me.txtStudentNameInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentNameInput.Location = New System.Drawing.Point(633, 38)
        Me.txtStudentNameInput.Name = "txtStudentNameInput"
        Me.txtStudentNameInput.Size = New System.Drawing.Size(191, 23)
        Me.txtStudentNameInput.TabIndex = 21
        Me.txtStudentNameInput.Text = "Input Student Name Here"
        Me.txtStudentNameInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.btnExit.Location = New System.Drawing.Point(607, 458)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(267, 95)
        Me.btnExit.TabIndex = 23
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.btnClear.Location = New System.Drawing.Point(607, 329)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(267, 95)
        Me.btnClear.TabIndex = 22
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblTest1Result
        '
        Me.lblTest1Result.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblTest1Result.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTest1Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTest1Result.Location = New System.Drawing.Point(7, 122)
        Me.lblTest1Result.Name = "lblTest1Result"
        Me.lblTest1Result.Size = New System.Drawing.Size(112, 32)
        Me.lblTest1Result.TabIndex = 24
        Me.lblTest1Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTest2Result
        '
        Me.lblTest2Result.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblTest2Result.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTest2Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTest2Result.Location = New System.Drawing.Point(125, 122)
        Me.lblTest2Result.Name = "lblTest2Result"
        Me.lblTest2Result.Size = New System.Drawing.Size(112, 32)
        Me.lblTest2Result.TabIndex = 25
        Me.lblTest2Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTest3Result
        '
        Me.lblTest3Result.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblTest3Result.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTest3Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTest3Result.Location = New System.Drawing.Point(243, 122)
        Me.lblTest3Result.Name = "lblTest3Result"
        Me.lblTest3Result.Size = New System.Drawing.Size(112, 32)
        Me.lblTest3Result.TabIndex = 26
        Me.lblTest3Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTest4Result
        '
        Me.lblTest4Result.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblTest4Result.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTest4Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTest4Result.Location = New System.Drawing.Point(361, 122)
        Me.lblTest4Result.Name = "lblTest4Result"
        Me.lblTest4Result.Size = New System.Drawing.Size(112, 32)
        Me.lblTest4Result.TabIndex = 27
        Me.lblTest4Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAvgGradeLetter
        '
        Me.lblAvgGradeLetter.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblAvgGradeLetter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAvgGradeLetter.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvgGradeLetter.Location = New System.Drawing.Point(253, 225)
        Me.lblAvgGradeLetter.Name = "lblAvgGradeLetter"
        Me.lblAvgGradeLetter.Size = New System.Drawing.Size(96, 39)
        Me.lblAvgGradeLetter.TabIndex = 28
        Me.lblAvgGradeLetter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnupdate
        '
        Me.btnupdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.Location = New System.Drawing.Point(643, 122)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(164, 25)
        Me.btnupdate.TabIndex = 29
        Me.btnupdate.Text = "Update Student Name"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'lstStudent
        '
        Me.lstStudent.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstStudent.FormattingEnabled = True
        Me.lstStudent.ItemHeight = 16
        Me.lstStudent.Location = New System.Drawing.Point(607, 153)
        Me.lstStudent.Name = "lstStudent"
        Me.lstStudent.Size = New System.Drawing.Size(246, 116)
        Me.lstStudent.TabIndex = 5
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(886, 565)
        Me.Controls.Add(Me.lstStudent)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.lblAvgGradeLetter)
        Me.Controls.Add(Me.lblTest4Result)
        Me.Controls.Add(Me.lblTest3Result)
        Me.Controls.Add(Me.lblTest2Result)
        Me.Controls.Add(Me.lblTest1Result)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.txtStudentNameInput)
        Me.Controls.Add(Me.btnInputStudent)
        Me.Controls.Add(Me.lblAvgGradeNum)
        Me.Controls.Add(Me.chkModTest4)
        Me.Controls.Add(Me.chkModTest3)
        Me.Controls.Add(Me.chkModTest2)
        Me.Controls.Add(Me.btnCalcAvg)
        Me.Controls.Add(Me.chkModTest1)
        Me.Controls.Add(Me.txtTest4)
        Me.Controls.Add(Me.txtTest3)
        Me.Controls.Add(Me.txtTest2)
        Me.Controls.Add(Me.txtTest1)
        Me.Controls.Add(Me.lstOutput)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.btnTest4)
        Me.Controls.Add(Me.btnTest3)
        Me.Controls.Add(Me.btnTest2)
        Me.Controls.Add(Me.btnTest1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnTest1 As Button
    Friend WithEvents btnTest2 As Button
    Friend WithEvents btnTest3 As Button
    Friend WithEvents btnTest4 As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents lstOutput As ListBox
    Friend WithEvents txtTest1 As TextBox
    Friend WithEvents txtTest2 As TextBox
    Friend WithEvents txtTest3 As TextBox
    Friend WithEvents txtTest4 As TextBox
    Friend WithEvents chkModTest1 As CheckBox
    Friend WithEvents btnCalcAvg As Button
    Friend WithEvents chkModTest2 As CheckBox
    Friend WithEvents chkModTest3 As CheckBox
    Friend WithEvents chkModTest4 As CheckBox
    Friend WithEvents lblAvgGradeNum As Label
    Friend WithEvents btnInputStudent As Button
    Friend WithEvents txtStudentNameInput As TextBox
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lblTest1Result As Label
    Friend WithEvents lblTest2Result As Label
    Friend WithEvents lblTest3Result As Label
    Friend WithEvents lblTest4Result As Label
    Friend WithEvents lblAvgGradeLetter As Label
    Friend WithEvents btnupdate As Button
    Friend WithEvents lstStudent As ListBox
End Class
