﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each txt In {txtTest1, txtTest2, txtTest3, txtTest4}
            txt.Text = ""
            txt.Enabled = False
        Next

        For Each rad In {chkModTest1, chkModTest2, chkModTest3, chkModTest4}
            rad.Checked = False
        Next

        For Each btn In {btnTest1, btnTest2, btnTest3, btnTest4}
            btn.Enabled = False
        Next
    End Sub

    Private Sub chkModTest1_CheckedChanged(sender As Object, e As EventArgs) Handles chkModTest1.CheckedChanged
        If chkModTest1.Checked = True Then
            txtTest1.Enabled = True
            btnTest1.Enabled = True
        End If
        If chkModTest1.Checked = False Then
            txtTest1.Enabled = False
            btnTest1.Enabled = False
        End If
    End Sub

    Private Sub chkModTest2_CheckedChanged(sender As Object, e As EventArgs) Handles chkModTest2.CheckedChanged
        If chkModTest2.Checked = True Then
            txtTest2.Enabled = True
            btnTest2.Enabled = True
        End If
        If chkModTest2.Checked = False Then
            txtTest2.Enabled = False
            btnTest2.Enabled = False
        End If
    End Sub

    Private Sub chkModTest3_CheckedChanged(sender As Object, e As EventArgs) Handles chkModTest3.CheckedChanged
        If chkModTest3.Checked = True Then
            txtTest3.Enabled = True
            btnTest3.Enabled = True
        End If
        If chkModTest3.Checked = False Then
            txtTest3.Enabled = False
            btnTest3.Enabled = False
        End If
    End Sub

    Private Sub chkModTest4_CheckedChanged(sender As Object, e As EventArgs) Handles chkModTest4.CheckedChanged
        If chkModTest4.Checked = True Then
            txtTest4.Enabled = True
            btnTest4.Enabled = True
        End If
        If chkModTest4.Checked = False Then
            txtTest4.Enabled = False
            btnTest4.Enabled = False
        End If
    End Sub

    Private Sub btnTest1_Click(sender As Object, e As EventArgs) Handles btnTest1.Click
        Dim TestOneInput As Integer
        TestOneInput = CInt(txtTest1.Text)
        lblTest1Result.Text = TestOneInput

        If lblTest1Result.Text < 0 Then
            lblTest1Result.Text = ""
            MessageBox.Show("The number should be greater than or equal to 0!!")
        ElseIf lblTest1Result.Text > 100 Then
            lblTest1Result.Text = ""
            MessageBox.Show("The number should be less than or equal to 100!!")
        End If
    End Sub

    Private Sub btnTest2_Click(sender As Object, e As EventArgs) Handles btnTest2.Click
        Dim TestTwoInput As Integer
        TestTwoInput = CInt(txtTest2.Text)
        lblTest2Result.Text = TestTwoInput

        If lblTest2Result.Text < 0 Then
            lblTest2Result.Text = ""
            MessageBox.Show("The number should be greater than or equal to 0!!")
        ElseIf lblTest2Result.Text > 100 Then
            lblTest2Result.Text = ""
            MessageBox.Show("The number should be less than or equal to 100!!")
        End If
    End Sub

    Private Sub btnTest3_Click(sender As Object, e As EventArgs) Handles btnTest3.Click
        Dim TestThreeInput As Integer
        TestThreeInput = CInt(txtTest3.Text)
        lblTest3Result.Text = TestThreeInput

        If lblTest3Result.Text < 0 Then
            lblTest3Result.Text = ""
            MessageBox.Show("The number should be greater than or equal to 0!!")
        ElseIf lblTest3Result.Text > 100 Then
            lblTest3Result.Text = ""
            MessageBox.Show("The number should be less than or equal to 100!!")
        End If
    End Sub

    Private Sub btnTest4_Click(sender As Object, e As EventArgs) Handles btnTest4.Click
        Dim TestFourInput As Integer
        TestFourInput = CInt(txtTest4.Text)
        lblTest4Result.Text = TestFourInput

        If lblTest4Result.Text < 0 Then
            lblTest4Result.Text = ""
            MessageBox.Show("The number should be greater than or equal to 0!!")
        ElseIf lblTest4Result.Text > 100 Then
            lblTest4Result.Text = ""
            MessageBox.Show("The number should be less than or equal to 100!!")
        End If
    End Sub

    Private Sub btnCalcAvg_Click(sender As Object, e As EventArgs) Handles btnCalcAvg.Click
        Dim GradeAvg As Integer
        Dim Test1Res As Integer
        Dim Test2Res As Integer
        Dim Test3Res As Integer
        Dim Test4Res As Integer

        Test1Res = CInt(lblTest1Result.Text)
        Test2Res = CInt(lblTest2Result.Text)
        Test3Res = CInt(lblTest3Result.Text)
        Test4Res = CInt(lblTest4Result.Text)

        GradeAvg = (Test1Res + Test2Res + Test3Res + Test4Res) / 4

        lblAvgGradeNum.Text = GradeAvg

        If lblAvgGradeNum.Text >= 0 And lblAvgGradeNum.Text <= 59 Then
            lblAvgGradeLetter.Text = "F"
        ElseIf lblAvgGradeNum.Text >= 60 And lblAvgGradeNum.Text <= 69 Then
            lblAvgGradeLetter.Text = "D"
        ElseIf lblAvgGradeNum.Text >= 70 And lblAvgGradeNum.Text <= 79 Then
            lblAvgGradeLetter.Text = "C"
        ElseIf lblAvgGradeNum.Text >= 80 And lblAvgGradeNum.Text <= 89 Then
            lblAvgGradeLetter.Text = "B"
        ElseIf lblAvgGradeNum.Text >= 90 And lblAvgGradeNum.Text <= 100 Then
            lblAvgGradeLetter.Text = "A"
        End If

    End Sub

    Private Sub btnInputStudent_Click(sender As Object, e As EventArgs) Handles btnInputStudent.Click
        Dim StudentName As String
        StudentName = CStr(txtStudentNameInput.Text)

        lstStudent.Items.Add(StudentName)

    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Dim Name As String = lstStudent.SelectedIndex

        lstStudent.Items.RemoveAt(Name)
        lstStudent.Items.Insert(Name, txtStudentNameInput.Text)
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim Grade As String = lblAvgGradeNum.Text
        Dim GradeLetter As String = lblAvgGradeLetter.Text
        Dim Name As String = lstStudent.SelectedItem

        lstOutput.Items.Add("Name: " & Name & "." & " Grade: " & GradeLetter & " Percent: " & Grade & "%")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblTest1Result.Text = String.Empty
        txtTest1.Text = String.Empty
        lblTest2Result.Text = String.Empty
        txtTest2.Text = String.Empty
        lblTest3Result.Text = String.Empty
        txtTest3.Text = String.Empty
        lblTest4Result.Text = String.Empty
        txtTest4.Text = String.Empty
        lblAvgGradeNum.Text = String.Empty
        lblAvgGradeLetter.Text = String.Empty
        lstStudent.Items.Clear()
        lstOutput.Items.Clear()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
