﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMovieName = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblDirector = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblProducer = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblYearRe = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCreate
        '
        Me.btnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreate.Location = New System.Drawing.Point(318, 312)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(128, 57)
        Me.btnCreate.TabIndex = 0
        Me.btnCreate.Text = "Create File"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(318, 375)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(128, 57)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblMovieName
        '
        Me.lblMovieName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMovieName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMovieName.Location = New System.Drawing.Point(284, 54)
        Me.lblMovieName.Name = "lblMovieName"
        Me.lblMovieName.Size = New System.Drawing.Size(187, 27)
        Me.lblMovieName.TabIndex = 3
        Me.lblMovieName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(147, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(106, 27)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Name of Movie:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(147, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 27)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Name of Director of Movie:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDirector
        '
        Me.lblDirector.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDirector.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDirector.Location = New System.Drawing.Point(284, 96)
        Me.lblDirector.Name = "lblDirector"
        Me.lblDirector.Size = New System.Drawing.Size(187, 27)
        Me.lblDirector.TabIndex = 5
        Me.lblDirector.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(147, 140)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 27)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Name of Movie Producer:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblProducer
        '
        Me.lblProducer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProducer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProducer.Location = New System.Drawing.Point(284, 139)
        Me.lblProducer.Name = "lblProducer"
        Me.lblProducer.Size = New System.Drawing.Size(187, 27)
        Me.lblProducer.TabIndex = 7
        Me.lblProducer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(147, 186)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 27)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Year of Movie Release:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblYearRe
        '
        Me.lblYearRe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblYearRe.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYearRe.Location = New System.Drawing.Point(284, 185)
        Me.lblYearRe.Name = "lblYearRe"
        Me.lblYearRe.Size = New System.Drawing.Size(187, 27)
        Me.lblYearRe.TabIndex = 9
        Me.lblYearRe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblYearRe)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblProducer)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblDirector)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblMovieName)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCreate)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnCreate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblMovieName As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblDirector As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblProducer As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblYearRe As Label
End Class
