﻿Public Class Form1

    Structure MovieInformation
        Dim strMovieName As String
        Dim strMovieDirector As String
        Dim strMovieProducer As String
        Dim strYearRelease As String
    End Structure

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Dim MovieInfo As MovieInformation

        With MovieInfo
            .strMovieName = "Godzilla"
            .strMovieDirector = "Gareth Edwards"
            .strMovieProducer = "Legendary Pictures"
            .strYearRelease = "2014"
        End With

        lblMovieName.Text = MovieInfo.strMovieName
        lblDirector.Text = MovieInfo.strMovieDirector
        lblProducer.Text = MovieInfo.strMovieProducer
        lblYearRe.Text = MovieInfo.strYearRelease
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
