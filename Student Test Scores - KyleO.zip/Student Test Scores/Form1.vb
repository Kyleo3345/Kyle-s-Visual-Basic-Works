﻿Imports System.IO
Public Class Form1
    Private strFilename As String = String.Empty
    Dim blnIsChanged As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each txt In {txtStudent1, txtStudent2, txtStudent3, txtStudent4, txtStudent5, txtStudent6,
            txtStud1Test1, txtStud1Test2, txtStud1Test3, txtStud1Test4, txtStud1Test5,
            txtStud2Test1, txtStud2Test2, txtStud2Test3, txtStud2Test4, txtStud2Test5,
            txtStud3Test1, txtStud3Test2, txtStud3Test3, txtStud3Test4, txtStud3Test5,
            txtStud4Test1, txtStud4Test2, txtStud4Test3, txtStud4Test4, txtStud4Test5,
            txtStud5Test1, txtStud5Test2, txtStud5Test3, txtStud5Test4, txtStud5Test5,
            txtStud6Test1, txtStud6Test2, txtStud6Test3, txtStud6Test4, txtStud6Test5}
            txt.Text = ""
        Next

        For Each lbl In {lblStud1Result, lblStud2Result, lblStud3Result, lblStud4Result, lblStud5Result, lblStud6Result}
            lbl.Text = ""
        Next
    End Sub

    Private Sub btnCalulate_Click(sender As Object, e As EventArgs) Handles btnCalulate.Click
        For Each txt In {txtStud1Test1, txtStud1Test2, txtStud1Test3, txtStud1Test4, txtStud1Test5,
            txtStud2Test1, txtStud2Test2, txtStud2Test3, txtStud2Test4, txtStud2Test5,
            txtStud3Test1, txtStud3Test2, txtStud3Test3, txtStud3Test4, txtStud3Test5,
            txtStud4Test1, txtStud4Test2, txtStud4Test3, txtStud4Test4, txtStud4Test5,
            txtStud5Test1, txtStud5Test2, txtStud5Test3, txtStud5Test4, txtStud5Test5,
            txtStud6Test1, txtStud6Test2, txtStud6Test3, txtStud6Test4, txtStud6Test5}
            If txt.Text < 0 Then
                txt.Text = ""
                MessageBox.Show("The number should be greater than or equal to 0!!")
            ElseIf txt.Text > 100 Then
                txt.Text = ""
                MessageBox.Show("The number should be less than or equal to 100!!")
            End If
        Next

        Dim GradeAvg1 As Double
        Dim GradeAvg2 As Double
        Dim GradeAvg3 As Double
        Dim GradeAvg4 As Double
        Dim GradeAvg5 As Double
        Dim GradeAvg6 As Double

        Dim Stud1Test1 As Double = txtStud1Test1.Text
        Dim Stud1Test2 As Double = txtStud1Test2.Text
        Dim Stud1Test3 As Double = txtStud1Test3.Text
        Dim Stud1Test4 As Double = txtStud1Test4.Text
        Dim Stud1Test5 As Double = txtStud1Test5.Text

        Dim Stud2Test1 As Double = txtStud2Test1.Text
        Dim Stud2Test2 As Double = txtStud2Test2.Text
        Dim Stud2Test3 As Double = txtStud2Test3.Text
        Dim Stud2Test4 As Double = txtStud2Test4.Text
        Dim Stud2Test5 As Double = txtStud2Test5.Text

        Dim Stud3Test1 As Double = txtStud3Test1.Text
        Dim Stud3Test2 As Double = txtStud3Test2.Text
        Dim Stud3Test3 As Double = txtStud3Test3.Text
        Dim Stud3Test4 As Double = txtStud3Test4.Text
        Dim Stud3Test5 As Double = txtStud3Test5.Text

        Dim Stud4Test1 As Double = txtStud4Test1.Text
        Dim Stud4Test2 As Double = txtStud4Test2.Text
        Dim Stud4Test3 As Double = txtStud4Test3.Text
        Dim Stud4Test4 As Double = txtStud4Test4.Text
        Dim Stud4Test5 As Double = txtStud4Test5.Text

        Dim Stud5Test1 As Double = txtStud5Test1.Text
        Dim Stud5Test2 As Double = txtStud5Test2.Text
        Dim Stud5Test3 As Double = txtStud5Test3.Text
        Dim Stud5Test4 As Double = txtStud5Test4.Text
        Dim Stud5Test5 As Double = txtStud5Test5.Text

        Dim Stud6Test1 As Double = txtStud6Test1.Text
        Dim Stud6Test2 As Double = txtStud6Test2.Text
        Dim Stud6Test3 As Double = txtStud6Test3.Text
        Dim Stud6Test4 As Double = txtStud6Test4.Text
        Dim Stud6Test5 As Double = txtStud6Test5.Text

        GradeAvg1 = (Stud1Test1 + Stud1Test2 + Stud1Test3 + Stud1Test4 + Stud1Test5) / 5
        GradeAvg2 = (Stud2Test1 + Stud2Test2 + Stud2Test3 + Stud2Test4 + Stud2Test5) / 5
        GradeAvg3 = (Stud3Test1 + Stud3Test2 + Stud3Test3 + Stud3Test4 + Stud3Test5) / 5
        GradeAvg4 = (Stud4Test1 + Stud4Test2 + Stud4Test3 + Stud4Test4 + Stud4Test5) / 5
        GradeAvg5 = (Stud5Test1 + Stud5Test2 + Stud5Test3 + Stud5Test4 + Stud5Test5) / 5
        GradeAvg6 = (Stud6Test1 + Stud6Test2 + Stud6Test3 + Stud6Test4 + Stud6Test5) / 5

        lblStud1Result.Text = GradeAvg1
        lblStud2Result.Text = GradeAvg2
        lblStud3Result.Text = GradeAvg3
        lblStud4Result.Text = GradeAvg4
        lblStud5Result.Text = GradeAvg5
        lblStud6Result.Text = GradeAvg6


    End Sub
    Sub ClearFileData()
        txtStudent1.Clear()
        txtStud1Test1.Clear()
        txtStud1Test2.Clear()
        txtStud1Test3.Clear()
        txtStud1Test4.Clear()
        txtStud1Test5.Clear()

        txtStudent2.Clear()
        txtStud2Test1.Clear()
        txtStud2Test2.Clear()
        txtStud2Test3.Clear()
        txtStud2Test4.Clear()
        txtStud2Test5.Clear()

        txtStudent3.Clear()
        txtStud3Test1.Clear()
        txtStud3Test2.Clear()
        txtStud3Test3.Clear()
        txtStud3Test4.Clear()
        txtStud3Test5.Clear()

        txtStudent4.Clear()
        txtStud4Test1.Clear()
        txtStud4Test2.Clear()
        txtStud4Test3.Clear()
        txtStud4Test4.Clear()
        txtStud4Test5.Clear()

        txtStudent5.Clear()
        txtStud5Test1.Clear()
        txtStud5Test2.Clear()
        txtStud5Test3.Clear()
        txtStud5Test4.Clear()
        txtStud5Test5.Clear()

        txtStudent6.Clear()
        txtStud6Test1.Clear()
        txtStud6Test2.Clear()
        txtStud6Test3.Clear()
        txtStud6Test4.Clear()
        txtStud6Test5.Clear()

        strFilename = String.Empty

        blnIsChanged = False
    End Sub

    Sub OpenFile()
        Dim inputFile As StreamReader

        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            strFilename = OpenFileDialog1.FileName

            Try
                inputFile = File.OpenText(strFilename)
                txtStudent1.Text = inputFile.ReadToEnd
                txtStud1Test1.Text = inputFile.ReadToEnd
                txtStud1Test2.Text = inputFile.ReadToEnd
                txtStud1Test3.Text = inputFile.ReadToEnd
                txtStud1Test4.Text = inputFile.ReadToEnd
                txtStud1Test5.Text = inputFile.ReadToEnd

                txtStudent2.Text = inputFile.ReadToEnd
                txtStud2Test1.Text = inputFile.ReadToEnd
                txtStud2Test2.Text = inputFile.ReadToEnd
                txtStud2Test3.Text = inputFile.ReadToEnd
                txtStud2Test4.Text = inputFile.ReadToEnd
                txtStud2Test5.Text = inputFile.ReadToEnd

                txtStudent3.Text = inputFile.ReadToEnd
                txtStud3Test1.Text = inputFile.ReadToEnd
                txtStud3Test2.Text = inputFile.ReadToEnd
                txtStud3Test3.Text = inputFile.ReadToEnd
                txtStud3Test4.Text = inputFile.ReadToEnd
                txtStud3Test5.Text = inputFile.ReadToEnd

                txtStudent4.Text = inputFile.ReadToEnd
                txtStud4Test1.Text = inputFile.ReadToEnd
                txtStud4Test2.Text = inputFile.ReadToEnd
                txtStud4Test3.Text = inputFile.ReadToEnd
                txtStud4Test4.Text = inputFile.ReadToEnd
                txtStud4Test5.Text = inputFile.ReadToEnd

                txtStudent5.Text = inputFile.ReadToEnd
                txtStud5Test1.Text = inputFile.ReadToEnd
                txtStud5Test2.Text = inputFile.ReadToEnd
                txtStud5Test3.Text = inputFile.ReadToEnd
                txtStud5Test4.Text = inputFile.ReadToEnd
                txtStud5Test5.Text = inputFile.ReadToEnd

                txtStudent6.Text = inputFile.ReadToEnd
                txtStud6Test1.Text = inputFile.ReadToEnd
                txtStud6Test2.Text = inputFile.ReadToEnd
                txtStud6Test3.Text = inputFile.ReadToEnd
                txtStud6Test4.Text = inputFile.ReadToEnd
                txtStud6Test5.Text = inputFile.ReadToEnd

                inputFile.Close()

                blnIsChanged = False
            Catch ex As Exception
                MessageBox.Show("Retrieval Error!")
            End Try
        End If
    End Sub

    Sub SaveFile()
        Dim outputFile As StreamWriter

        Try
            outputFile = File.CreateText(strFilename)
            outputFile.Write(txtStud1Test1.Text, txtStud1Test2.Text, txtStud1Test3.Text, txtStud1Test4.Text, txtStud1Test5.Text,
            txtStud2Test1.Text, txtStud2Test2.Text, txtStud2Test3.Text, txtStud2Test4.Text, txtStud2Test5.Text,
            txtStud3Test1.Text, txtStud3Test2.Text, txtStud3Test3.Text, txtStud3Test4.Text, txtStud3Test5.Text,
            txtStud4Test1.Text, txtStud4Test2.Text, txtStud4Test3.Text, txtStud4Test4.Text, txtStud4Test5.Text,
            txtStud5Test1.Text, txtStud5Test2.Text, txtStud5Test3.Text, txtStud5Test4.Text, txtStud5Test5.Text,
            txtStud6Test1.Text, txtStud6Test2.Text, txtStud6Test3.Text, txtStud6Test4.Text, txtStud6Test5.Text,
            lblStud1Result.Text, lblStud2Result.Text, lblStud3Result.Text, lblStud4Result.Text, lblStud5Result.Text, lblStud6Result.Text)
            outputFile.Close()
            blnIsChanged = False

        Catch ex As Exception
            MessageBox.Show("Creation Error!")
        End Try

    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuFileNew_Click(sender As Object, e As EventArgs) Handles mnuFileNew.Click
        If blnIsChanged = True Then
            If MessageBox.Show("The current document is not saved. " & "Are you Sure?", "Confirm",
            MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                ClearFileData()
            End If
        Else
            ClearFileData()
        End If
    End Sub

    Private Sub mnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click
        If blnIsChanged = True Then
            If MessageBox.Show("The current document is not saved. " & "Are you Sure?", "Confirm",
            MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                ClearFileData()
                OpenFile()
            End If
        Else
            ClearFileData()
            OpenFile()
        End If
    End Sub

    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        If strFilename = String.Empty Then
            If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                strFilename = SaveFileDialog1.FileName
                SaveFile()
            End If
        Else
            SaveFile()
        End If
    End Sub

    Private Sub mnuFileSaveAs_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            strFilename = SaveFileDialog1.FileName
            SaveFile()
        End If
    End Sub

    Private Sub TxtChange(sender As Object, e As EventArgs) Handles txtStudent6.TextChanged, txtStudent5.TextChanged, txtStudent4.TextChanged, txtStudent3.TextChanged, txtStudent2.TextChanged, txtStudent1.TextChanged, txtStud6Test5.TextChanged, txtStud6Test4.TextChanged, txtStud6Test3.TextChanged, txtStud6Test2.TextChanged, txtStud6Test1.TextChanged, txtStud5Test5.TextChanged, txtStud5Test4.TextChanged, txtStud5Test3.TextChanged, txtStud5Test2.TextChanged, txtStud5Test1.TextChanged, txtStud4Test5.TextChanged, txtStud4Test4.TextChanged, txtStud4Test3.TextChanged, txtStud4Test2.TextChanged, txtStud4Test1.TextChanged, txtStud3Test5.TextChanged, txtStud3Test4.TextChanged, txtStud3Test3.TextChanged, txtStud3Test2.TextChanged, txtStud3Test1.TextChanged, txtStud2Test5.TextChanged, txtStud2Test4.TextChanged, txtStud2Test3.TextChanged, txtStud2Test2.TextChanged, txtStud2Test1.TextChanged, txtStud1Test5.TextChanged, txtStud1Test4.TextChanged, txtStud1Test3.TextChanged, txtStud1Test2.TextChanged, txtStud1Test1.TextChanged
        blnIsChanged = True
    End Sub
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If blnIsChanged = True Then
            If MessageBox.Show("The current document is not saved. " & "Do you wish to discard the changes you made?",
            "Confirm", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                e.Cancel = False
            Else
                e.Cancel = True
            End If
        End If
    End Sub
End Class
