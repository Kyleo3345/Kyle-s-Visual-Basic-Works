﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblStud6Result = New System.Windows.Forms.Label()
        Me.lblStud5Result = New System.Windows.Forms.Label()
        Me.lblStud4Result = New System.Windows.Forms.Label()
        Me.lblStud3Result = New System.Windows.Forms.Label()
        Me.lblStud2Result = New System.Windows.Forms.Label()
        Me.txtStud6Test5 = New System.Windows.Forms.TextBox()
        Me.txtStud6Test4 = New System.Windows.Forms.TextBox()
        Me.txtStud6Test3 = New System.Windows.Forms.TextBox()
        Me.txtStud6Test2 = New System.Windows.Forms.TextBox()
        Me.txtStud6Test1 = New System.Windows.Forms.TextBox()
        Me.txtStud5Test5 = New System.Windows.Forms.TextBox()
        Me.txtStud5Test4 = New System.Windows.Forms.TextBox()
        Me.txtStud5Test3 = New System.Windows.Forms.TextBox()
        Me.txtStud5Test2 = New System.Windows.Forms.TextBox()
        Me.txtStud5Test1 = New System.Windows.Forms.TextBox()
        Me.txtStud4Test5 = New System.Windows.Forms.TextBox()
        Me.txtStud4Test4 = New System.Windows.Forms.TextBox()
        Me.txtStud4Test3 = New System.Windows.Forms.TextBox()
        Me.txtStud4Test2 = New System.Windows.Forms.TextBox()
        Me.txtStud4Test1 = New System.Windows.Forms.TextBox()
        Me.txtStud3Test5 = New System.Windows.Forms.TextBox()
        Me.txtStud3Test4 = New System.Windows.Forms.TextBox()
        Me.txtStud3Test3 = New System.Windows.Forms.TextBox()
        Me.txtStud3Test2 = New System.Windows.Forms.TextBox()
        Me.txtStud3Test1 = New System.Windows.Forms.TextBox()
        Me.txtStud2Test5 = New System.Windows.Forms.TextBox()
        Me.txtStud2Test4 = New System.Windows.Forms.TextBox()
        Me.txtStud2Test3 = New System.Windows.Forms.TextBox()
        Me.txtStud2Test2 = New System.Windows.Forms.TextBox()
        Me.txtStud2Test1 = New System.Windows.Forms.TextBox()
        Me.txtStud1Test5 = New System.Windows.Forms.TextBox()
        Me.txtStud1Test4 = New System.Windows.Forms.TextBox()
        Me.txtStud1Test3 = New System.Windows.Forms.TextBox()
        Me.txtStud1Test2 = New System.Windows.Forms.TextBox()
        Me.txtStud1Test1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtStudent6 = New System.Windows.Forms.TextBox()
        Me.txtStudent5 = New System.Windows.Forms.TextBox()
        Me.txtStudent4 = New System.Windows.Forms.TextBox()
        Me.txtStudent3 = New System.Windows.Forms.TextBox()
        Me.txtStudent2 = New System.Windows.Forms.TextBox()
        Me.txtStudent1 = New System.Windows.Forms.TextBox()
        Me.lblStud1Result = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCalulate = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileSaveAs = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblStud6Result)
        Me.GroupBox1.Controls.Add(Me.lblStud5Result)
        Me.GroupBox1.Controls.Add(Me.lblStud4Result)
        Me.GroupBox1.Controls.Add(Me.lblStud3Result)
        Me.GroupBox1.Controls.Add(Me.lblStud2Result)
        Me.GroupBox1.Controls.Add(Me.txtStud6Test5)
        Me.GroupBox1.Controls.Add(Me.txtStud6Test4)
        Me.GroupBox1.Controls.Add(Me.txtStud6Test3)
        Me.GroupBox1.Controls.Add(Me.txtStud6Test2)
        Me.GroupBox1.Controls.Add(Me.txtStud6Test1)
        Me.GroupBox1.Controls.Add(Me.txtStud5Test5)
        Me.GroupBox1.Controls.Add(Me.txtStud5Test4)
        Me.GroupBox1.Controls.Add(Me.txtStud5Test3)
        Me.GroupBox1.Controls.Add(Me.txtStud5Test2)
        Me.GroupBox1.Controls.Add(Me.txtStud5Test1)
        Me.GroupBox1.Controls.Add(Me.txtStud4Test5)
        Me.GroupBox1.Controls.Add(Me.txtStud4Test4)
        Me.GroupBox1.Controls.Add(Me.txtStud4Test3)
        Me.GroupBox1.Controls.Add(Me.txtStud4Test2)
        Me.GroupBox1.Controls.Add(Me.txtStud4Test1)
        Me.GroupBox1.Controls.Add(Me.txtStud3Test5)
        Me.GroupBox1.Controls.Add(Me.txtStud3Test4)
        Me.GroupBox1.Controls.Add(Me.txtStud3Test3)
        Me.GroupBox1.Controls.Add(Me.txtStud3Test2)
        Me.GroupBox1.Controls.Add(Me.txtStud3Test1)
        Me.GroupBox1.Controls.Add(Me.txtStud2Test5)
        Me.GroupBox1.Controls.Add(Me.txtStud2Test4)
        Me.GroupBox1.Controls.Add(Me.txtStud2Test3)
        Me.GroupBox1.Controls.Add(Me.txtStud2Test2)
        Me.GroupBox1.Controls.Add(Me.txtStud2Test1)
        Me.GroupBox1.Controls.Add(Me.txtStud1Test5)
        Me.GroupBox1.Controls.Add(Me.txtStud1Test4)
        Me.GroupBox1.Controls.Add(Me.txtStud1Test3)
        Me.GroupBox1.Controls.Add(Me.txtStud1Test2)
        Me.GroupBox1.Controls.Add(Me.txtStud1Test1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtStudent6)
        Me.GroupBox1.Controls.Add(Me.txtStudent5)
        Me.GroupBox1.Controls.Add(Me.txtStudent4)
        Me.GroupBox1.Controls.Add(Me.txtStudent3)
        Me.GroupBox1.Controls.Add(Me.txtStudent2)
        Me.GroupBox1.Controls.Add(Me.txtStudent1)
        Me.GroupBox1.Controls.Add(Me.lblStud1Result)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(776, 326)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Student Data"
        '
        'lblStud6Result
        '
        Me.lblStud6Result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStud6Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStud6Result.Location = New System.Drawing.Point(680, 275)
        Me.lblStud6Result.Name = "lblStud6Result"
        Me.lblStud6Result.Size = New System.Drawing.Size(67, 21)
        Me.lblStud6Result.TabIndex = 44
        '
        'lblStud5Result
        '
        Me.lblStud5Result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStud5Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStud5Result.Location = New System.Drawing.Point(680, 233)
        Me.lblStud5Result.Name = "lblStud5Result"
        Me.lblStud5Result.Size = New System.Drawing.Size(67, 21)
        Me.lblStud5Result.TabIndex = 43
        '
        'lblStud4Result
        '
        Me.lblStud4Result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStud4Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStud4Result.Location = New System.Drawing.Point(680, 187)
        Me.lblStud4Result.Name = "lblStud4Result"
        Me.lblStud4Result.Size = New System.Drawing.Size(67, 21)
        Me.lblStud4Result.TabIndex = 42
        '
        'lblStud3Result
        '
        Me.lblStud3Result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStud3Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStud3Result.Location = New System.Drawing.Point(680, 140)
        Me.lblStud3Result.Name = "lblStud3Result"
        Me.lblStud3Result.Size = New System.Drawing.Size(67, 21)
        Me.lblStud3Result.TabIndex = 41
        '
        'lblStud2Result
        '
        Me.lblStud2Result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStud2Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStud2Result.Location = New System.Drawing.Point(680, 96)
        Me.lblStud2Result.Name = "lblStud2Result"
        Me.lblStud2Result.Size = New System.Drawing.Size(67, 21)
        Me.lblStud2Result.TabIndex = 40
        '
        'txtStud6Test5
        '
        Me.txtStud6Test5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud6Test5.Location = New System.Drawing.Point(465, 275)
        Me.txtStud6Test5.Name = "txtStud6Test5"
        Me.txtStud6Test5.Size = New System.Drawing.Size(36, 21)
        Me.txtStud6Test5.TabIndex = 39
        '
        'txtStud6Test4
        '
        Me.txtStud6Test4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud6Test4.Location = New System.Drawing.Point(423, 275)
        Me.txtStud6Test4.Name = "txtStud6Test4"
        Me.txtStud6Test4.Size = New System.Drawing.Size(36, 21)
        Me.txtStud6Test4.TabIndex = 38
        '
        'txtStud6Test3
        '
        Me.txtStud6Test3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud6Test3.Location = New System.Drawing.Point(381, 275)
        Me.txtStud6Test3.Name = "txtStud6Test3"
        Me.txtStud6Test3.Size = New System.Drawing.Size(36, 21)
        Me.txtStud6Test3.TabIndex = 37
        '
        'txtStud6Test2
        '
        Me.txtStud6Test2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud6Test2.Location = New System.Drawing.Point(339, 275)
        Me.txtStud6Test2.Name = "txtStud6Test2"
        Me.txtStud6Test2.Size = New System.Drawing.Size(36, 21)
        Me.txtStud6Test2.TabIndex = 36
        '
        'txtStud6Test1
        '
        Me.txtStud6Test1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud6Test1.Location = New System.Drawing.Point(297, 275)
        Me.txtStud6Test1.Name = "txtStud6Test1"
        Me.txtStud6Test1.Size = New System.Drawing.Size(36, 21)
        Me.txtStud6Test1.TabIndex = 35
        '
        'txtStud5Test5
        '
        Me.txtStud5Test5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud5Test5.Location = New System.Drawing.Point(465, 232)
        Me.txtStud5Test5.Name = "txtStud5Test5"
        Me.txtStud5Test5.Size = New System.Drawing.Size(36, 21)
        Me.txtStud5Test5.TabIndex = 34
        '
        'txtStud5Test4
        '
        Me.txtStud5Test4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud5Test4.Location = New System.Drawing.Point(423, 232)
        Me.txtStud5Test4.Name = "txtStud5Test4"
        Me.txtStud5Test4.Size = New System.Drawing.Size(36, 21)
        Me.txtStud5Test4.TabIndex = 33
        '
        'txtStud5Test3
        '
        Me.txtStud5Test3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud5Test3.Location = New System.Drawing.Point(381, 232)
        Me.txtStud5Test3.Name = "txtStud5Test3"
        Me.txtStud5Test3.Size = New System.Drawing.Size(36, 21)
        Me.txtStud5Test3.TabIndex = 32
        '
        'txtStud5Test2
        '
        Me.txtStud5Test2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud5Test2.Location = New System.Drawing.Point(339, 232)
        Me.txtStud5Test2.Name = "txtStud5Test2"
        Me.txtStud5Test2.Size = New System.Drawing.Size(36, 21)
        Me.txtStud5Test2.TabIndex = 31
        '
        'txtStud5Test1
        '
        Me.txtStud5Test1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud5Test1.Location = New System.Drawing.Point(297, 232)
        Me.txtStud5Test1.Name = "txtStud5Test1"
        Me.txtStud5Test1.Size = New System.Drawing.Size(36, 21)
        Me.txtStud5Test1.TabIndex = 30
        '
        'txtStud4Test5
        '
        Me.txtStud4Test5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud4Test5.Location = New System.Drawing.Point(465, 187)
        Me.txtStud4Test5.Name = "txtStud4Test5"
        Me.txtStud4Test5.Size = New System.Drawing.Size(36, 21)
        Me.txtStud4Test5.TabIndex = 29
        '
        'txtStud4Test4
        '
        Me.txtStud4Test4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud4Test4.Location = New System.Drawing.Point(423, 187)
        Me.txtStud4Test4.Name = "txtStud4Test4"
        Me.txtStud4Test4.Size = New System.Drawing.Size(36, 21)
        Me.txtStud4Test4.TabIndex = 28
        '
        'txtStud4Test3
        '
        Me.txtStud4Test3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud4Test3.Location = New System.Drawing.Point(381, 187)
        Me.txtStud4Test3.Name = "txtStud4Test3"
        Me.txtStud4Test3.Size = New System.Drawing.Size(36, 21)
        Me.txtStud4Test3.TabIndex = 27
        '
        'txtStud4Test2
        '
        Me.txtStud4Test2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud4Test2.Location = New System.Drawing.Point(339, 187)
        Me.txtStud4Test2.Name = "txtStud4Test2"
        Me.txtStud4Test2.Size = New System.Drawing.Size(36, 21)
        Me.txtStud4Test2.TabIndex = 26
        '
        'txtStud4Test1
        '
        Me.txtStud4Test1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud4Test1.Location = New System.Drawing.Point(297, 187)
        Me.txtStud4Test1.Name = "txtStud4Test1"
        Me.txtStud4Test1.Size = New System.Drawing.Size(36, 21)
        Me.txtStud4Test1.TabIndex = 25
        '
        'txtStud3Test5
        '
        Me.txtStud3Test5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud3Test5.Location = New System.Drawing.Point(465, 139)
        Me.txtStud3Test5.Name = "txtStud3Test5"
        Me.txtStud3Test5.Size = New System.Drawing.Size(36, 21)
        Me.txtStud3Test5.TabIndex = 24
        '
        'txtStud3Test4
        '
        Me.txtStud3Test4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud3Test4.Location = New System.Drawing.Point(423, 139)
        Me.txtStud3Test4.Name = "txtStud3Test4"
        Me.txtStud3Test4.Size = New System.Drawing.Size(36, 21)
        Me.txtStud3Test4.TabIndex = 23
        '
        'txtStud3Test3
        '
        Me.txtStud3Test3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud3Test3.Location = New System.Drawing.Point(381, 139)
        Me.txtStud3Test3.Name = "txtStud3Test3"
        Me.txtStud3Test3.Size = New System.Drawing.Size(36, 21)
        Me.txtStud3Test3.TabIndex = 22
        '
        'txtStud3Test2
        '
        Me.txtStud3Test2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud3Test2.Location = New System.Drawing.Point(339, 139)
        Me.txtStud3Test2.Name = "txtStud3Test2"
        Me.txtStud3Test2.Size = New System.Drawing.Size(36, 21)
        Me.txtStud3Test2.TabIndex = 21
        '
        'txtStud3Test1
        '
        Me.txtStud3Test1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud3Test1.Location = New System.Drawing.Point(297, 139)
        Me.txtStud3Test1.Name = "txtStud3Test1"
        Me.txtStud3Test1.Size = New System.Drawing.Size(36, 21)
        Me.txtStud3Test1.TabIndex = 20
        '
        'txtStud2Test5
        '
        Me.txtStud2Test5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud2Test5.Location = New System.Drawing.Point(465, 96)
        Me.txtStud2Test5.Name = "txtStud2Test5"
        Me.txtStud2Test5.Size = New System.Drawing.Size(36, 21)
        Me.txtStud2Test5.TabIndex = 19
        '
        'txtStud2Test4
        '
        Me.txtStud2Test4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud2Test4.Location = New System.Drawing.Point(423, 96)
        Me.txtStud2Test4.Name = "txtStud2Test4"
        Me.txtStud2Test4.Size = New System.Drawing.Size(36, 21)
        Me.txtStud2Test4.TabIndex = 18
        '
        'txtStud2Test3
        '
        Me.txtStud2Test3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud2Test3.Location = New System.Drawing.Point(381, 96)
        Me.txtStud2Test3.Name = "txtStud2Test3"
        Me.txtStud2Test3.Size = New System.Drawing.Size(36, 21)
        Me.txtStud2Test3.TabIndex = 17
        '
        'txtStud2Test2
        '
        Me.txtStud2Test2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud2Test2.Location = New System.Drawing.Point(339, 96)
        Me.txtStud2Test2.Name = "txtStud2Test2"
        Me.txtStud2Test2.Size = New System.Drawing.Size(36, 21)
        Me.txtStud2Test2.TabIndex = 16
        '
        'txtStud2Test1
        '
        Me.txtStud2Test1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud2Test1.Location = New System.Drawing.Point(297, 96)
        Me.txtStud2Test1.Name = "txtStud2Test1"
        Me.txtStud2Test1.Size = New System.Drawing.Size(36, 21)
        Me.txtStud2Test1.TabIndex = 15
        '
        'txtStud1Test5
        '
        Me.txtStud1Test5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud1Test5.Location = New System.Drawing.Point(465, 51)
        Me.txtStud1Test5.Name = "txtStud1Test5"
        Me.txtStud1Test5.Size = New System.Drawing.Size(36, 21)
        Me.txtStud1Test5.TabIndex = 14
        '
        'txtStud1Test4
        '
        Me.txtStud1Test4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud1Test4.Location = New System.Drawing.Point(423, 51)
        Me.txtStud1Test4.Name = "txtStud1Test4"
        Me.txtStud1Test4.Size = New System.Drawing.Size(36, 21)
        Me.txtStud1Test4.TabIndex = 13
        '
        'txtStud1Test3
        '
        Me.txtStud1Test3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud1Test3.Location = New System.Drawing.Point(381, 51)
        Me.txtStud1Test3.Name = "txtStud1Test3"
        Me.txtStud1Test3.Size = New System.Drawing.Size(36, 21)
        Me.txtStud1Test3.TabIndex = 12
        '
        'txtStud1Test2
        '
        Me.txtStud1Test2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud1Test2.Location = New System.Drawing.Point(339, 51)
        Me.txtStud1Test2.Name = "txtStud1Test2"
        Me.txtStud1Test2.Size = New System.Drawing.Size(36, 21)
        Me.txtStud1Test2.TabIndex = 11
        '
        'txtStud1Test1
        '
        Me.txtStud1Test1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStud1Test1.Location = New System.Drawing.Point(297, 51)
        Me.txtStud1Test1.Name = "txtStud1Test1"
        Me.txtStud1Test1.Size = New System.Drawing.Size(36, 21)
        Me.txtStud1Test1.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(677, 31)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 17)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Average"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(359, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Test Scores"
        '
        'txtStudent6
        '
        Me.txtStudent6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStudent6.Location = New System.Drawing.Point(6, 275)
        Me.txtStudent6.Name = "txtStudent6"
        Me.txtStudent6.Size = New System.Drawing.Size(187, 21)
        Me.txtStudent6.TabIndex = 7
        '
        'txtStudent5
        '
        Me.txtStudent5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStudent5.Location = New System.Drawing.Point(6, 232)
        Me.txtStudent5.Name = "txtStudent5"
        Me.txtStudent5.Size = New System.Drawing.Size(187, 21)
        Me.txtStudent5.TabIndex = 6
        '
        'txtStudent4
        '
        Me.txtStudent4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStudent4.Location = New System.Drawing.Point(6, 187)
        Me.txtStudent4.Name = "txtStudent4"
        Me.txtStudent4.Size = New System.Drawing.Size(187, 21)
        Me.txtStudent4.TabIndex = 5
        '
        'txtStudent3
        '
        Me.txtStudent3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStudent3.Location = New System.Drawing.Point(6, 139)
        Me.txtStudent3.Name = "txtStudent3"
        Me.txtStudent3.Size = New System.Drawing.Size(187, 21)
        Me.txtStudent3.TabIndex = 4
        '
        'txtStudent2
        '
        Me.txtStudent2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStudent2.Location = New System.Drawing.Point(6, 96)
        Me.txtStudent2.Name = "txtStudent2"
        Me.txtStudent2.Size = New System.Drawing.Size(187, 21)
        Me.txtStudent2.TabIndex = 3
        '
        'txtStudent1
        '
        Me.txtStudent1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStudent1.Location = New System.Drawing.Point(6, 51)
        Me.txtStudent1.Name = "txtStudent1"
        Me.txtStudent1.Size = New System.Drawing.Size(187, 21)
        Me.txtStudent1.TabIndex = 2
        '
        'lblStud1Result
        '
        Me.lblStud1Result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStud1Result.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStud1Result.Location = New System.Drawing.Point(680, 52)
        Me.lblStud1Result.Name = "lblStud1Result"
        Me.lblStud1Result.Size = New System.Drawing.Size(67, 21)
        Me.lblStud1Result.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(80, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Name"
        '
        'btnCalulate
        '
        Me.btnCalulate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalulate.Location = New System.Drawing.Point(329, 390)
        Me.btnCalulate.Name = "btnCalulate"
        Me.btnCalulate.Size = New System.Drawing.Size(157, 48)
        Me.btnCalulate.TabIndex = 1
        Me.btnCalulate.Text = "Calculate Average Grade"
        Me.btnCalulate.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileNew, Me.mnuFileOpen, Me.mnuFileSave, Me.mnuFileSaveAs, Me.ToolStripSeparator1, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuFileNew
        '
        Me.mnuFileNew.Name = "mnuFileNew"
        Me.mnuFileNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.mnuFileNew.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileNew.Text = "&New"
        '
        'mnuFileOpen
        '
        Me.mnuFileOpen.Name = "mnuFileOpen"
        Me.mnuFileOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnuFileOpen.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileOpen.Text = "&Open"
        '
        'mnuFileSave
        '
        Me.mnuFileSave.Name = "mnuFileSave"
        Me.mnuFileSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuFileSave.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileSave.Text = "&Save"
        '
        'mnuFileSaveAs
        '
        Me.mnuFileSaveAs.Name = "mnuFileSaveAs"
        Me.mnuFileSaveAs.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileSaveAs.Text = "Save &As"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(143, 6)
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.mnuFileExit.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileExit.Text = "&Exit"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = " "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnCalulate)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnCalulate As Button
    Friend WithEvents txtStudent1 As TextBox
    Friend WithEvents lblStud1Result As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtStudent6 As TextBox
    Friend WithEvents txtStudent5 As TextBox
    Friend WithEvents txtStudent4 As TextBox
    Friend WithEvents txtStudent3 As TextBox
    Friend WithEvents txtStudent2 As TextBox
    Friend WithEvents txtStud1Test5 As TextBox
    Friend WithEvents txtStud1Test4 As TextBox
    Friend WithEvents txtStud1Test3 As TextBox
    Friend WithEvents txtStud1Test2 As TextBox
    Friend WithEvents txtStud1Test1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtStud2Test5 As TextBox
    Friend WithEvents txtStud2Test4 As TextBox
    Friend WithEvents txtStud2Test3 As TextBox
    Friend WithEvents txtStud2Test2 As TextBox
    Friend WithEvents txtStud2Test1 As TextBox
    Friend WithEvents txtStud3Test5 As TextBox
    Friend WithEvents txtStud3Test4 As TextBox
    Friend WithEvents txtStud3Test3 As TextBox
    Friend WithEvents txtStud3Test2 As TextBox
    Friend WithEvents txtStud3Test1 As TextBox
    Friend WithEvents txtStud6Test5 As TextBox
    Friend WithEvents txtStud6Test4 As TextBox
    Friend WithEvents txtStud6Test3 As TextBox
    Friend WithEvents txtStud6Test2 As TextBox
    Friend WithEvents txtStud6Test1 As TextBox
    Friend WithEvents txtStud5Test5 As TextBox
    Friend WithEvents txtStud5Test4 As TextBox
    Friend WithEvents txtStud5Test3 As TextBox
    Friend WithEvents txtStud5Test2 As TextBox
    Friend WithEvents txtStud5Test1 As TextBox
    Friend WithEvents txtStud4Test5 As TextBox
    Friend WithEvents txtStud4Test4 As TextBox
    Friend WithEvents txtStud4Test3 As TextBox
    Friend WithEvents txtStud4Test2 As TextBox
    Friend WithEvents txtStud4Test1 As TextBox
    Friend WithEvents lblStud6Result As Label
    Friend WithEvents lblStud5Result As Label
    Friend WithEvents lblStud4Result As Label
    Friend WithEvents lblStud3Result As Label
    Friend WithEvents lblStud2Result As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuFileNew As ToolStripMenuItem
    Friend WithEvents mnuFileOpen As ToolStripMenuItem
    Friend WithEvents mnuFileSave As ToolStripMenuItem
    Friend WithEvents mnuFileSaveAs As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents mnuFileExit As ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
End Class
