﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim dblCostofItem As Double
        Dim dblMarkup As Double
        Dim dblRetailPrice As Double

        dblCostofItem = CDbl(txtCost.Text)
        dblMarkup = CDbl(txtMarkup.Text)

        dblRetailPrice = dblCostofItem + dblMarkup

        lblRetailPrice.Text = dblRetailPrice.ToString("C")

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
