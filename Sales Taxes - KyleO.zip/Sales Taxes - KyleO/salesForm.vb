﻿'Solution: sales
'Me: salesForm.vb
'Date: 23-Jan-2023
'Author: Kyle Osterman
'Purpose: To calculate taxes

Option Explicit On
Option Strict On


Public Class salesForm
    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Calculate.Click
        Dim dblRetailSale As Double
        Dim dblSalesTaxRate As Double
        Dim dblAmountOfSalesTax As Double
        Dim dblTotalOfTheSales As Double

        dblRetailSale = CDbl(txtRetailSale.Text)
        dblSalesTaxRate = CDbl(txtSalesTaxRate.Text)

        dblAmountOfSalesTax = dblRetailSale * dblSalesTaxRate
        dblTotalOfTheSales = dblAmountOfSalesTax + dblRetailSale

        lblAmountOfSalesTax.Text = dblAmountOfSalesTax.ToString("c")
        lblTotalOfTheSales.Text = dblTotalOfTheSales.ToString("c")

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtRetailSale.TextChanged

    End Sub
End Class
