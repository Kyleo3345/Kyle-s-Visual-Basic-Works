﻿Option Explicit On
Option Strict On


Public Class salesSplash
    Private Sub tmrSplash_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrSplash.Tick
        tmrSplash.Enabled = False
        Me.Close()
    End Sub
End Class