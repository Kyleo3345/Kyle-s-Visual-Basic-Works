﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class salesForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtRetailSale = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSalesTaxRate = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Calculate = New System.Windows.Forms.Button()
        Me.lblAmountOfSalesTax = New System.Windows.Forms.Label()
        Me.lblTotalOfTheSales = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtRetailSale
        '
        Me.txtRetailSale.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtRetailSale.Location = New System.Drawing.Point(215, 41)
        Me.txtRetailSale.Name = "txtRetailSale"
        Me.txtRetailSale.Size = New System.Drawing.Size(103, 26)
        Me.txtRetailSale.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(109, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Retail Sale"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(78, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Sales Tax Rate"
        '
        'txtSalesTaxRate
        '
        Me.txtSalesTaxRate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtSalesTaxRate.Location = New System.Drawing.Point(215, 87)
        Me.txtSalesTaxRate.Name = "txtSalesTaxRate"
        Me.txtSalesTaxRate.Size = New System.Drawing.Size(103, 26)
        Me.txtSalesTaxRate.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label3.Location = New System.Drawing.Point(43, 217)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(152, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Amount of Sales tax"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label4.Location = New System.Drawing.Point(70, 263)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(125, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Total of the Sale"
        '
        'Calculate
        '
        Me.Calculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Calculate.Location = New System.Drawing.Point(215, 145)
        Me.Calculate.Name = "Calculate"
        Me.Calculate.Size = New System.Drawing.Size(91, 35)
        Me.Calculate.TabIndex = 8
        Me.Calculate.Text = "Calculate"
        Me.Calculate.UseVisualStyleBackColor = True
        '
        'lblAmountOfSalesTax
        '
        Me.lblAmountOfSalesTax.AutoSize = True
        Me.lblAmountOfSalesTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblAmountOfSalesTax.Location = New System.Drawing.Point(229, 217)
        Me.lblAmountOfSalesTax.Name = "lblAmountOfSalesTax"
        Me.lblAmountOfSalesTax.Size = New System.Drawing.Size(53, 20)
        Me.lblAmountOfSalesTax.TabIndex = 9
        Me.lblAmountOfSalesTax.Text = "$ 0.00"
        '
        'lblTotalOfTheSales
        '
        Me.lblTotalOfTheSales.AutoSize = True
        Me.lblTotalOfTheSales.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblTotalOfTheSales.Location = New System.Drawing.Point(229, 263)
        Me.lblTotalOfTheSales.Name = "lblTotalOfTheSales"
        Me.lblTotalOfTheSales.Size = New System.Drawing.Size(53, 20)
        Me.lblTotalOfTheSales.TabIndex = 10
        Me.lblTotalOfTheSales.Text = "$ 0.00"
        '
        'salesForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(377, 312)
        Me.Controls.Add(Me.lblTotalOfTheSales)
        Me.Controls.Add(Me.lblAmountOfSalesTax)
        Me.Controls.Add(Me.Calculate)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtSalesTaxRate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtRetailSale)
        Me.Name = "salesForm"
        Me.Text = "Sales Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtRetailSale As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSalesTaxRate As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Calculate As Button
    Friend WithEvents lblAmountOfSalesTax As Label
    Friend WithEvents lblTotalOfTheSales As Label
End Class
