﻿Public Class Form1
    Dim strArticles As String() = {"the ", "a ", "one ", "two ", "three ", "four ", "five ", "some ", "any "}
    Dim strNouns As String() = {"skunk ", "dog ", "cat ", "fish ", "bird ", "city ", "planet ", "house ", "ground ", "car ", "he ",
            "her ", "himself ", "herself ", "they ", "them ", "themselves "}
    Dim strVerbs As String() = {"drove ", "flew ", "jumped ", "ran ", "skipped ", "hopped ", "walked ", "dug ", "rammed "}
    Dim strPrepositions As String() = {"to ", "from ", "over ", "under ", "on ", "beneath ", "toward ", "inside ", "into "}
    Dim rand As New Random()

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click

        Dim rndArt1 As String
        Dim rndArt2 As String
        Dim rndNoun1 As String
        Dim rndNoun2 As String
        Dim rndVerb As String
        Dim rndPreposition As String
        Dim counter As Integer = 1

        Do
            rndArt1 = strArticles(rand.Next(9))
            rndArt2 = strArticles(rand.Next(9))
            rndNoun1 = strNouns(rand.Next(17))
            rndNoun2 = strNouns(rand.Next(17))
            rndVerb = strVerbs(rand.Next(9))
            rndPreposition = strPrepositions(rand.Next(9))

            lstDisplay.Items.Add(String.Concat(rndArt1, rndNoun1, rndVerb, rndPreposition, rndArt2,
               rndNoun2, "." & vbCrLf))
            counter += 1
        Loop While counter <= 1



    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lstDisplay.Items.Clear()
    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
