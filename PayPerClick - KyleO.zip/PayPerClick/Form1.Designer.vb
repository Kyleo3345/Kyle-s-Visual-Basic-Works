﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.lblRevenueWeek4 = New System.Windows.Forms.Label()
        Me.lblRevenueWeek3 = New System.Windows.Forms.Label()
        Me.lblRevenueWeek2 = New System.Windows.Forms.Label()
        Me.lblRevenueWeek1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.txtAdCostPerWeek = New System.Windows.Forms.TextBox()
        Me.txtAdClicksWeek1 = New System.Windows.Forms.TextBox()
        Me.txtAdClicksWeek2 = New System.Windows.Forms.TextBox()
        Me.txtAdClicksWeek3 = New System.Windows.Forms.TextBox()
        Me.txtAdClicksWeek4 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBox1.Location = New System.Drawing.Point(12, 12)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(474, 51)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "This application calculates the amount of advertising revenue paid to a Web site " &
    "that displays links to a selected vendor."
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBox2.Location = New System.Drawing.Point(12, 83)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(195, 26)
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = "Advertising cost per week:"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.Location = New System.Drawing.Point(12, 128)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(537, 13)
        Me.TextBox3.TabIndex = 3
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBox4.Location = New System.Drawing.Point(34, 161)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(102, 112)
        Me.TextBox4.TabIndex = 4
        Me.TextBox4.Text = "Number of Ad Clicks during the past 4 weekly periods"
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBox5.Location = New System.Drawing.Point(231, 199)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(13, 22)
        Me.TextBox5.TabIndex = 5
        Me.TextBox5.Text = "1"
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBox6.Location = New System.Drawing.Point(231, 242)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(13, 22)
        Me.TextBox6.TabIndex = 7
        Me.TextBox6.Text = "2"
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBox7.Location = New System.Drawing.Point(231, 287)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(13, 22)
        Me.TextBox7.TabIndex = 9
        Me.TextBox7.Text = "3"
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.TextBox8.Location = New System.Drawing.Point(231, 329)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(13, 22)
        Me.TextBox8.TabIndex = 11
        Me.TextBox8.Text = "4"
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.TextBox9.Location = New System.Drawing.Point(407, 161)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(79, 23)
        Me.TextBox9.TabIndex = 13
        Me.TextBox9.Text = "Revenue"
        '
        'lblRevenueWeek4
        '
        Me.lblRevenueWeek4.BackColor = System.Drawing.SystemColors.Control
        Me.lblRevenueWeek4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevenueWeek4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRevenueWeek4.Location = New System.Drawing.Point(396, 328)
        Me.lblRevenueWeek4.Name = "lblRevenueWeek4"
        Me.lblRevenueWeek4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lblRevenueWeek4.Size = New System.Drawing.Size(90, 23)
        Me.lblRevenueWeek4.TabIndex = 17
        '
        'lblRevenueWeek3
        '
        Me.lblRevenueWeek3.BackColor = System.Drawing.SystemColors.Control
        Me.lblRevenueWeek3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevenueWeek3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRevenueWeek3.Location = New System.Drawing.Point(396, 286)
        Me.lblRevenueWeek3.Name = "lblRevenueWeek3"
        Me.lblRevenueWeek3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lblRevenueWeek3.Size = New System.Drawing.Size(90, 23)
        Me.lblRevenueWeek3.TabIndex = 16
        '
        'lblRevenueWeek2
        '
        Me.lblRevenueWeek2.BackColor = System.Drawing.SystemColors.Control
        Me.lblRevenueWeek2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevenueWeek2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRevenueWeek2.Location = New System.Drawing.Point(396, 241)
        Me.lblRevenueWeek2.Name = "lblRevenueWeek2"
        Me.lblRevenueWeek2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lblRevenueWeek2.Size = New System.Drawing.Size(90, 23)
        Me.lblRevenueWeek2.TabIndex = 15
        '
        'lblRevenueWeek1
        '
        Me.lblRevenueWeek1.BackColor = System.Drawing.SystemColors.Control
        Me.lblRevenueWeek1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRevenueWeek1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRevenueWeek1.Location = New System.Drawing.Point(396, 198)
        Me.lblRevenueWeek1.Name = "lblRevenueWeek1"
        Me.lblRevenueWeek1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lblRevenueWeek1.Size = New System.Drawing.Size(90, 23)
        Me.lblRevenueWeek1.TabIndex = 14
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnExit.Location = New System.Drawing.Point(377, 410)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(145, 30)
        Me.btnExit.TabIndex = 20
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnClear.Location = New System.Drawing.Point(212, 410)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(145, 30)
        Me.btnClear.TabIndex = 19
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnCalc
        '
        Me.btnCalc.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnCalc.Location = New System.Drawing.Point(42, 410)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(145, 30)
        Me.btnCalc.TabIndex = 18
        Me.btnCalc.Text = "C&alculate"
        Me.btnCalc.UseVisualStyleBackColor = False
        '
        'txtAdCostPerWeek
        '
        Me.txtAdCostPerWeek.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdCostPerWeek.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdCostPerWeek.Location = New System.Drawing.Point(259, 81)
        Me.txtAdCostPerWeek.Name = "txtAdCostPerWeek"
        Me.txtAdCostPerWeek.Size = New System.Drawing.Size(98, 26)
        Me.txtAdCostPerWeek.TabIndex = 21
        '
        'txtAdClicksWeek1
        '
        Me.txtAdClicksWeek1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdClicksWeek1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdClicksWeek1.Location = New System.Drawing.Point(259, 197)
        Me.txtAdClicksWeek1.Name = "txtAdClicksWeek1"
        Me.txtAdClicksWeek1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtAdClicksWeek1.Size = New System.Drawing.Size(98, 26)
        Me.txtAdClicksWeek1.TabIndex = 22
        '
        'txtAdClicksWeek2
        '
        Me.txtAdClicksWeek2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdClicksWeek2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdClicksWeek2.Location = New System.Drawing.Point(259, 240)
        Me.txtAdClicksWeek2.Name = "txtAdClicksWeek2"
        Me.txtAdClicksWeek2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtAdClicksWeek2.Size = New System.Drawing.Size(98, 26)
        Me.txtAdClicksWeek2.TabIndex = 23
        '
        'txtAdClicksWeek3
        '
        Me.txtAdClicksWeek3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdClicksWeek3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdClicksWeek3.Location = New System.Drawing.Point(259, 283)
        Me.txtAdClicksWeek3.Name = "txtAdClicksWeek3"
        Me.txtAdClicksWeek3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtAdClicksWeek3.Size = New System.Drawing.Size(98, 26)
        Me.txtAdClicksWeek3.TabIndex = 24
        '
        'txtAdClicksWeek4
        '
        Me.txtAdClicksWeek4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtAdClicksWeek4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdClicksWeek4.Location = New System.Drawing.Point(259, 327)
        Me.txtAdClicksWeek4.Name = "txtAdClicksWeek4"
        Me.txtAdClicksWeek4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtAdClicksWeek4.Size = New System.Drawing.Size(98, 26)
        Me.txtAdClicksWeek4.TabIndex = 25
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(557, 452)
        Me.Controls.Add(Me.txtAdClicksWeek4)
        Me.Controls.Add(Me.txtAdClicksWeek3)
        Me.Controls.Add(Me.txtAdClicksWeek2)
        Me.Controls.Add(Me.txtAdClicksWeek1)
        Me.Controls.Add(Me.txtAdCostPerWeek)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblRevenueWeek4)
        Me.Controls.Add(Me.lblRevenueWeek3)
        Me.Controls.Add(Me.lblRevenueWeek2)
        Me.Controls.Add(Me.lblRevenueWeek1)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form1"
        Me.Text = "Pay Per Click Advertising Revenue"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents lblRevenueWeek4 As Label
    Friend WithEvents lblRevenueWeek3 As Label
    Friend WithEvents lblRevenueWeek2 As Label
    Friend WithEvents lblRevenueWeek1 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCalc As Button
    Friend WithEvents txtAdCostPerWeek As TextBox
    Friend WithEvents txtAdClicksWeek1 As TextBox
    Friend WithEvents txtAdClicksWeek2 As TextBox
    Friend WithEvents txtAdClicksWeek3 As TextBox
    Friend WithEvents txtAdClicksWeek4 As TextBox
End Class
