﻿Public Class Splash
    Private Sub tmrSplash_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrSplash.Tick
        tmrSplash.Enabled = False
        Me.Close()
    End Sub
End Class