﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim decRevenueWeek1 As Decimal
        Dim decRevenueWeek2 As Decimal
        Dim decRevenueWeek3 As Decimal
        Dim decRevenueWeek4 As Decimal

        Try

            decRevenueWeek1 = CDec(txtAdCostPerWeek.Text) / CDec(txtAdClicksWeek1.Text)
            decRevenueWeek2 = CDec(txtAdCostPerWeek.Text) / CDec(txtAdClicksWeek2.Text)
            decRevenueWeek3 = CDec(txtAdCostPerWeek.Text) / CDec(txtAdClicksWeek3.Text)
            decRevenueWeek4 = CDec(txtAdCostPerWeek.Text) / CDec(txtAdClicksWeek4.Text)

            lblRevenueWeek1.Text = decRevenueWeek1.ToString("c")
            lblRevenueWeek2.Text = decRevenueWeek2.ToString("c")
            lblRevenueWeek3.Text = decRevenueWeek3.ToString("c")
            lblRevenueWeek4.Text = decRevenueWeek4.ToString("c")

        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtAdCostPerWeek.Clear()
        txtAdClicksWeek1.Clear()
        txtAdClicksWeek2.Clear()
        txtAdClicksWeek3.Clear()
        txtAdClicksWeek4.Clear()
        lblRevenueWeek1.Text = String.Empty
        lblRevenueWeek2.Text = String.Empty
        lblRevenueWeek3.Text = String.Empty
        lblRevenueWeek4.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
