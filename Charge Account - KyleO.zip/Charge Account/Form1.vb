﻿Public Class Form1

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim ValidArr(17) As Integer
        Dim StrInput As Integer

        StrInput = CInt(txtInput.Text)

        ValidArr(0) = "5658845"
        ValidArr(1) = "4520125"
        ValidArr(2) = "7895122"
        ValidArr(3) = "8777541"
        ValidArr(4) = "8451277"
        ValidArr(5) = "1302850"
        ValidArr(6) = "8080152"
        ValidArr(7) = "4562555"
        ValidArr(8) = "5552012"
        ValidArr(9) = "5050552"
        ValidArr(10) = "7825877"
        ValidArr(11) = "1250255"
        ValidArr(12) = "1005231"
        ValidArr(13) = "6545231"
        ValidArr(14) = "3852085"
        ValidArr(15) = "7576651"
        ValidArr(16) = "7881200"
        ValidArr(17) = "4581002"

        If StrInput = ValidArr(0) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(1) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(2) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(3) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(4) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(5) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(6) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(7) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(8) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(9) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(10) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(11) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(12) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(13) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(14) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(15) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(16) Then
            lblOutput.Text = "Access Granted"
        ElseIf StrInput = ValidArr(17) Then
            lblOutput.Text = "Access Granted"
        Else
            lblOutput.Text = "Access Denied"
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtInput.Text = ""
        lblOutput.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Private Sub Splash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Splash.ShowDialog()
    End Sub
End Class
