﻿Imports System.Configuration
Imports System.Data
Imports System.Data.OleDb

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        StudentListDataGridView.DataSource = GetStudentList()


    End Sub

    Private Function GetStudentList() As DataTable
        Dim dtStudents As New DataTable

        Dim connString As String = ConfigurationManager.ConnectionStrings("dbx").ConnectionString

        Using conn As New OleDbConnection(connString)
            Using cmd As New OleDbCommand("SELECT * FROM Students", conn)

                conn.Open()

                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                dtStudents.Load(reader)

            End Using
        End Using

        Return dtStudents
    End Function


End Class
