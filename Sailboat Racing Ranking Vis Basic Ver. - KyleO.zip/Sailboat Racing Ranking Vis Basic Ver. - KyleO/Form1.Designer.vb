﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtB3R4 = New System.Windows.Forms.TextBox()
        Me.txtB3R3 = New System.Windows.Forms.TextBox()
        Me.txtB3R2 = New System.Windows.Forms.TextBox()
        Me.txtB3R1 = New System.Windows.Forms.TextBox()
        Me.txtB2R4 = New System.Windows.Forms.TextBox()
        Me.txtB2R3 = New System.Windows.Forms.TextBox()
        Me.txtB2R2 = New System.Windows.Forms.TextBox()
        Me.txtB2R1 = New System.Windows.Forms.TextBox()
        Me.txtB1R4 = New System.Windows.Forms.TextBox()
        Me.txtB1R3 = New System.Windows.Forms.TextBox()
        Me.txtB1R2 = New System.Windows.Forms.TextBox()
        Me.txtB1R1 = New System.Windows.Forms.TextBox()
        Me.lblRank3 = New System.Windows.Forms.Label()
        Me.lblTotal3 = New System.Windows.Forms.Label()
        Me.lblRank2 = New System.Windows.Forms.Label()
        Me.lblTotal2 = New System.Windows.Forms.Label()
        Me.lblRank1 = New System.Windows.Forms.Label()
        Me.lblTotal1 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(12, 340)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(183, 52)
        Me.btnCalc.TabIndex = 0
        Me.btnCalc.Text = "Calculate Ranks"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Controls.Add(Me.txtB3R4)
        Me.GroupBox1.Controls.Add(Me.txtB3R3)
        Me.GroupBox1.Controls.Add(Me.txtB3R2)
        Me.GroupBox1.Controls.Add(Me.txtB3R1)
        Me.GroupBox1.Controls.Add(Me.txtB2R4)
        Me.GroupBox1.Controls.Add(Me.txtB2R3)
        Me.GroupBox1.Controls.Add(Me.txtB2R2)
        Me.GroupBox1.Controls.Add(Me.txtB2R1)
        Me.GroupBox1.Controls.Add(Me.txtB1R4)
        Me.GroupBox1.Controls.Add(Me.txtB1R3)
        Me.GroupBox1.Controls.Add(Me.txtB1R2)
        Me.GroupBox1.Controls.Add(Me.txtB1R1)
        Me.GroupBox1.Controls.Add(Me.lblRank3)
        Me.GroupBox1.Controls.Add(Me.lblTotal3)
        Me.GroupBox1.Controls.Add(Me.lblRank2)
        Me.GroupBox1.Controls.Add(Me.lblTotal2)
        Me.GroupBox1.Controls.Add(Me.lblRank1)
        Me.GroupBox1.Controls.Add(Me.lblTotal1)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(776, 307)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Race Results"
        '
        'txtB3R4
        '
        Me.txtB3R4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB3R4.Location = New System.Drawing.Point(476, 221)
        Me.txtB3R4.Name = "txtB3R4"
        Me.txtB3R4.Size = New System.Drawing.Size(56, 26)
        Me.txtB3R4.TabIndex = 30
        '
        'txtB3R3
        '
        Me.txtB3R3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB3R3.Location = New System.Drawing.Point(363, 221)
        Me.txtB3R3.Name = "txtB3R3"
        Me.txtB3R3.Size = New System.Drawing.Size(56, 26)
        Me.txtB3R3.TabIndex = 29
        '
        'txtB3R2
        '
        Me.txtB3R2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB3R2.Location = New System.Drawing.Point(250, 221)
        Me.txtB3R2.Name = "txtB3R2"
        Me.txtB3R2.Size = New System.Drawing.Size(56, 26)
        Me.txtB3R2.TabIndex = 28
        '
        'txtB3R1
        '
        Me.txtB3R1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB3R1.Location = New System.Drawing.Point(139, 221)
        Me.txtB3R1.Name = "txtB3R1"
        Me.txtB3R1.Size = New System.Drawing.Size(56, 26)
        Me.txtB3R1.TabIndex = 27
        '
        'txtB2R4
        '
        Me.txtB2R4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB2R4.Location = New System.Drawing.Point(476, 162)
        Me.txtB2R4.Name = "txtB2R4"
        Me.txtB2R4.Size = New System.Drawing.Size(56, 26)
        Me.txtB2R4.TabIndex = 26
        '
        'txtB2R3
        '
        Me.txtB2R3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB2R3.Location = New System.Drawing.Point(363, 162)
        Me.txtB2R3.Name = "txtB2R3"
        Me.txtB2R3.Size = New System.Drawing.Size(56, 26)
        Me.txtB2R3.TabIndex = 25
        '
        'txtB2R2
        '
        Me.txtB2R2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB2R2.Location = New System.Drawing.Point(250, 162)
        Me.txtB2R2.Name = "txtB2R2"
        Me.txtB2R2.Size = New System.Drawing.Size(56, 26)
        Me.txtB2R2.TabIndex = 24
        '
        'txtB2R1
        '
        Me.txtB2R1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB2R1.Location = New System.Drawing.Point(139, 162)
        Me.txtB2R1.Name = "txtB2R1"
        Me.txtB2R1.Size = New System.Drawing.Size(56, 26)
        Me.txtB2R1.TabIndex = 23
        '
        'txtB1R4
        '
        Me.txtB1R4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB1R4.Location = New System.Drawing.Point(476, 100)
        Me.txtB1R4.Name = "txtB1R4"
        Me.txtB1R4.Size = New System.Drawing.Size(56, 26)
        Me.txtB1R4.TabIndex = 22
        '
        'txtB1R3
        '
        Me.txtB1R3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB1R3.Location = New System.Drawing.Point(363, 100)
        Me.txtB1R3.Name = "txtB1R3"
        Me.txtB1R3.Size = New System.Drawing.Size(56, 26)
        Me.txtB1R3.TabIndex = 21
        '
        'txtB1R2
        '
        Me.txtB1R2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB1R2.Location = New System.Drawing.Point(250, 100)
        Me.txtB1R2.Name = "txtB1R2"
        Me.txtB1R2.Size = New System.Drawing.Size(56, 26)
        Me.txtB1R2.TabIndex = 20
        '
        'txtB1R1
        '
        Me.txtB1R1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtB1R1.Location = New System.Drawing.Point(139, 100)
        Me.txtB1R1.Name = "txtB1R1"
        Me.txtB1R1.Size = New System.Drawing.Size(56, 26)
        Me.txtB1R1.TabIndex = 19
        '
        'lblRank3
        '
        Me.lblRank3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank3.Location = New System.Drawing.Point(685, 218)
        Me.lblRank3.Name = "lblRank3"
        Me.lblRank3.Size = New System.Drawing.Size(56, 26)
        Me.lblRank3.TabIndex = 18
        '
        'lblTotal3
        '
        Me.lblTotal3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal3.Location = New System.Drawing.Point(591, 218)
        Me.lblTotal3.Name = "lblTotal3"
        Me.lblTotal3.Size = New System.Drawing.Size(56, 26)
        Me.lblTotal3.TabIndex = 17
        '
        'lblRank2
        '
        Me.lblRank2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank2.Location = New System.Drawing.Point(685, 159)
        Me.lblRank2.Name = "lblRank2"
        Me.lblRank2.Size = New System.Drawing.Size(56, 26)
        Me.lblRank2.TabIndex = 16
        '
        'lblTotal2
        '
        Me.lblTotal2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal2.Location = New System.Drawing.Point(591, 159)
        Me.lblTotal2.Name = "lblTotal2"
        Me.lblTotal2.Size = New System.Drawing.Size(56, 26)
        Me.lblTotal2.TabIndex = 15
        '
        'lblRank1
        '
        Me.lblRank1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank1.Location = New System.Drawing.Point(685, 101)
        Me.lblRank1.Name = "lblRank1"
        Me.lblRank1.Size = New System.Drawing.Size(56, 26)
        Me.lblRank1.TabIndex = 14
        '
        'lblTotal1
        '
        Me.lblTotal1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal1.Location = New System.Drawing.Point(591, 101)
        Me.lblTotal1.Name = "lblTotal1"
        Me.lblTotal1.Size = New System.Drawing.Size(56, 26)
        Me.lblTotal1.TabIndex = 13
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(681, 49)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 20)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Rank"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(587, 49)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 20)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Total"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(472, 49)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 20)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Race 4"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(359, 49)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 20)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Race 3"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(246, 49)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Race 2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(135, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Race 1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(27, 223)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Boat #3:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(27, 164)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Boat #2:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(27, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 20)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Boat #1:"
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(345, 340)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(139, 52)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(649, 340)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(139, 52)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 401)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "Form1"
        Me.Text = "Sailboat Races with Rankings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtB3R4 As TextBox
    Friend WithEvents txtB3R3 As TextBox
    Friend WithEvents txtB3R2 As TextBox
    Friend WithEvents txtB3R1 As TextBox
    Friend WithEvents txtB2R4 As TextBox
    Friend WithEvents txtB2R3 As TextBox
    Friend WithEvents txtB2R2 As TextBox
    Friend WithEvents txtB2R1 As TextBox
    Friend WithEvents txtB1R4 As TextBox
    Friend WithEvents txtB1R3 As TextBox
    Friend WithEvents txtB1R2 As TextBox
    Friend WithEvents txtB1R1 As TextBox
    Friend WithEvents lblRank3 As Label
    Friend WithEvents lblTotal3 As Label
    Friend WithEvents lblRank2 As Label
    Friend WithEvents lblTotal2 As Label
    Friend WithEvents lblRank1 As Label
    Friend WithEvents lblTotal1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
