﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim Total1 As Integer
        Dim Total2 As Integer
        Dim Total3 As Integer
        Dim Limit1 As Integer
        Dim Limit2 As Integer
        Dim Limit3 As Integer
        Dim Limit4 As Integer

        Try
            Total1 = CInt(txtB1R1.Text) + CInt(txtB1R2.Text) + CInt(txtB1R3.Text) + CInt(txtB1R4.Text)
            Total2 = CInt(txtB2R1.Text) + CInt(txtB2R2.Text) + CInt(txtB2R3.Text) + CInt(txtB2R4.Text)
            Total3 = CInt(txtB3R1.Text) + CInt(txtB3R2.Text) + CInt(txtB3R3.Text) + CInt(txtB3R4.Text)

            lblTotal1.Text = Total1
            lblTotal2.Text = Total2
            lblTotal3.Text = Total3

            Limit1 = CInt(txtB1R1.Text) + CInt(txtB2R1.Text) + CInt(txtB3R1.Text)
            Limit2 = CInt(txtB1R2.Text) + CInt(txtB2R2.Text) + CInt(txtB3R2.Text)
            Limit3 = CInt(txtB1R3.Text) + CInt(txtB2R3.Text) + CInt(txtB3R3.Text)
            Limit4 = CInt(txtB1R4.Text) + CInt(txtB2R4.Text) + CInt(txtB3R4.Text)

        Catch ex As Exception

        End Try

        If Limit1 > 6 Then
            MessageBox.Show("Enter 1, 2 and 3 only for race 1")
        End If
        If Limit2 > 6 Then
            MessageBox.Show("Enter 1, 2 and 3 only for race 2")
        End If
        If Limit3 > 6 Then
            MessageBox.Show("Enter 1, 2 and 3 only for race 3")
        End If
        If Limit4 > 6 Then
            MessageBox.Show("Enter 1, 2 and 3 only for race 4")
        End If

        If lblTotal1.Text > lblTotal2.Text And lblTotal1.Text > lblTotal3.Text Then
            lblRank1.Text = "1"
        ElseIf lblTotal1.Text < lblTotal2.Text And lblTotal1.Text > lblTotal3.Text Then
            lblRank1.Text = "2"
        ElseIf lblTotal1.Text < lblTotal2.Text And lblTotal1.Text < lblTotal3.Text Then
            lblRank1.Text = "3"
        End If

        If lblTotal2.Text > lblTotal1.Text And lblTotal2.Text > lblTotal3.Text Then
            lblRank2.Text = "1"
        ElseIf lblTotal2.Text < lblTotal1.Text And lblTotal2.Text > lblTotal3.Text Then
            lblRank2.Text = "2"
        ElseIf lblTotal2.Text < lblTotal1.Text And lblTotal2.Text < lblTotal3.Text Then
            lblRank2.Text = "3"
        End If

        If lblTotal3.Text > lblTotal1.Text And lblTotal3.Text > lblTotal2.Text Then
            lblRank3.Text = "1"
        ElseIf lblTotal3.Text < lblTotal1.Text And lblTotal3.Text > lblTotal2.Text Then
            lblRank3.Text = "2"
        ElseIf lblTotal3.Text < lblTotal1.Text And lblTotal3.Text < lblTotal2.Text Then
            lblRank3.Text = "3"
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtB1R1.Text = ""
        txtB1R2.Text = ""
        txtB1R3.Text = ""
        txtB1R4.Text = ""
        txtB2R1.Text = ""
        txtB2R2.Text = ""
        txtB2R3.Text = ""
        txtB2R4.Text = ""
        txtB3R1.Text = ""
        txtB3R2.Text = ""
        txtB3R3.Text = ""
        txtB3R4.Text = ""

        lblTotal1.Text = String.Empty
        lblTotal2.Text = String.Empty
        lblTotal3.Text = String.Empty

        lblRank1.Text = String.Empty
        lblRank2.Text = String.Empty
        lblRank3.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
