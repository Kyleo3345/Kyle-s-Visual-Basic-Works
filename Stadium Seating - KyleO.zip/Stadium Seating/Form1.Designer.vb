﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtClassC = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtClassB = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtClassA = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblTotalRev = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblClassCrev = New System.Windows.Forms.Label()
        Me.lblClassBrev = New System.Windows.Forms.Label()
        Me.lblClassArev = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnCalcRev = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtClassC)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtClassB)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtClassA)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(257, 202)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tickets Sold"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label4.Location = New System.Drawing.Point(44, 141)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 17)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Class C:"
        '
        'txtClassC
        '
        Me.txtClassC.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtClassC.Location = New System.Drawing.Point(149, 141)
        Me.txtClassC.Name = "txtClassC"
        Me.txtClassC.Size = New System.Drawing.Size(72, 23)
        Me.txtClassC.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label3.Location = New System.Drawing.Point(44, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Class B:"
        '
        'txtClassB
        '
        Me.txtClassB.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtClassB.Location = New System.Drawing.Point(149, 112)
        Me.txtClassB.Name = "txtClassB"
        Me.txtClassB.Size = New System.Drawing.Size(72, 23)
        Me.txtClassB.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label2.Location = New System.Drawing.Point(44, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Class A:"
        '
        'txtClassA
        '
        Me.txtClassA.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtClassA.Location = New System.Drawing.Point(149, 80)
        Me.txtClassA.Name = "txtClassA"
        Me.txtClassA.Size = New System.Drawing.Size(72, 23)
        Me.txtClassA.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label1.Location = New System.Drawing.Point(6, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(215, 43)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Enter the number of tickets sold for each class of seats"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblTotalRev)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.lblClassCrev)
        Me.GroupBox2.Controls.Add(Me.lblClassBrev)
        Me.GroupBox2.Controls.Add(Me.lblClassArev)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.GroupBox2.Location = New System.Drawing.Point(297, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(257, 202)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Revenue Generated"
        '
        'lblTotalRev
        '
        Me.lblTotalRev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblTotalRev.Location = New System.Drawing.Point(121, 141)
        Me.lblTotalRev.Name = "lblTotalRev"
        Me.lblTotalRev.Size = New System.Drawing.Size(84, 17)
        Me.lblTotalRev.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label8.Location = New System.Drawing.Point(6, 141)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(105, 17)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Total Revenue:"
        '
        'lblClassCrev
        '
        Me.lblClassCrev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClassCrev.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblClassCrev.Location = New System.Drawing.Point(121, 95)
        Me.lblClassCrev.Name = "lblClassCrev"
        Me.lblClassCrev.Size = New System.Drawing.Size(84, 17)
        Me.lblClassCrev.TabIndex = 8
        '
        'lblClassBrev
        '
        Me.lblClassBrev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClassBrev.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblClassBrev.Location = New System.Drawing.Point(121, 69)
        Me.lblClassBrev.Name = "lblClassBrev"
        Me.lblClassBrev.Size = New System.Drawing.Size(84, 17)
        Me.lblClassBrev.TabIndex = 7
        '
        'lblClassArev
        '
        Me.lblClassArev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClassArev.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblClassArev.Location = New System.Drawing.Point(121, 40)
        Me.lblClassArev.Name = "lblClassArev"
        Me.lblClassArev.Size = New System.Drawing.Size(84, 17)
        Me.lblClassArev.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label5.Location = New System.Drawing.Point(40, 95)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 17)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Class C:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label6.Location = New System.Drawing.Point(40, 69)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 17)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Class B:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label7.Location = New System.Drawing.Point(40, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 17)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Class A:"
        '
        'btnCalcRev
        '
        Me.btnCalcRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnCalcRev.Location = New System.Drawing.Point(21, 238)
        Me.btnCalcRev.Name = "btnCalcRev"
        Me.btnCalcRev.Size = New System.Drawing.Size(145, 48)
        Me.btnCalcRev.TabIndex = 8
        Me.btnCalcRev.Text = "C&alculate Revenue"
        Me.btnCalcRev.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnClear.Location = New System.Drawing.Point(217, 238)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(145, 48)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnExit.Location = New System.Drawing.Point(409, 238)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(145, 48)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(586, 307)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalcRev)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Stadium Seating"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtClassC As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtClassB As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtClassA As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lblTotalRev As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblClassCrev As Label
    Friend WithEvents lblClassBrev As Label
    Friend WithEvents lblClassArev As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btnCalcRev As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
