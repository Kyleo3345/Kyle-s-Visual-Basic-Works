﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCalcRev_Click(sender As Object, e As EventArgs) Handles btnCalcRev.Click
        Dim decClassArev As Decimal
        Dim decClassBrev As Decimal
        Dim decClassCrev As Decimal
        Dim decTotalRev As Decimal

        Try
            decClassArev = CDec(txtClassA.Text) * 15
            decClassBrev = CDec(txtClassB.Text) * 12
            decClassCrev = CDec(txtClassC.Text) * 9

            lblClassArev.Text = decClassArev.ToString("c")
            lblClassBrev.Text = decClassBrev.ToString("c")
            lblClassCrev.Text = decClassCrev.ToString("c")

            decTotalRev = decClassArev + decClassBrev + decClassCrev
            lblTotalRev.Text = decTotalRev.ToString("c")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtClassA.Clear()
        txtClassB.Clear()
        txtClassC.Clear()

        lblClassArev.Text = String.Empty
        lblClassBrev.Text = String.Empty
        lblClassCrev.Text = String.Empty
        lblTotalRev.Text = String.Empty
    End Sub
    Private Sub StadiumSplash_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        StadiumSplash.ShowDialog()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object,
       ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are you sure?", "Quit Program?", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) =
            DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
End Class
